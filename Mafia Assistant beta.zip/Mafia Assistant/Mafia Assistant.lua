script_author("Miron Diamond")
script_name("Mafia Assistant")
script_version("1.0")

require("samp-api")
require("moonloader")
require "lib.moonloader"

local ffi = require("ffi")
local mrkeys = require("mrkeys")
local rkeys = require("rkeys")
local mimgui = require("mimgui")
local encoding = require("encoding")
local keys = require "vkeys"
local imgui = require 'imgui'
local encoding = require 'encoding'
local themes = import "Mafia Assistant/imgui_themes.lua"
local sampev = require "lib.samp.events"
local fa = require "faIcons"
local fa_glyph_ranges = imgui.ImGlyphRanges({ fa.min_range, fa.max_range })
local inicfg = require 'inicfg'
local directIni = "moonloader\\Mafia Assistant\\mafia_assistant.ini"
local mainIni = inicfg.load(nil, directIni)
local updateIni = inicfg.load(nil, update_path)
local dlstatus = require('moonloader').download_status

imgui.HotKey = require('imgui_addons').HotKey

hintid = ""
file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint"..hintid..".txt", "w")

encoding.default = 'CP1251'
u8 = encoding.UTF8

imgui.HotKey = require('imgui_addons').HotKey

local tLastKeys = {} -- ��� ����� ��������� ���������� ������ ��� �������������


HotKeyBinder = {
	v = {}
}

local HotKeyBMenu = {
	v = decodeJson(mainIni.HotKey.bindBMenu)
}

local HotKeyKPK = {
	v = decodeJson(mainIni.HotKey.bindKPK)
}

local HotKeyHint = {
	v = decodeJson(mainIni.HotKey.bindHint)
}

local HotKeyMenu = {
	v = decodeJson(mainIni.HotKey.bindMenu)
}

local HotKeyScream = {
	v = decodeJson(mainIni.HotKey.bindScream)
}

local HotKeyRPGun = {
	v = decodeJson(mainIni.HotKey.bindRPGun)
}

reasons = {
    [0] = '����',
    [1] = '/q',
    [2] = '������ ��������'
}

qwertyuiopasdfghjklzxcvbnm = getDistanceBetweenCoords3d(1,1,1,1,1,1)

local tag = "� {FF0000}[Mafia Assistant] {FFFFFF}"
local cl_samp = "{80BCFF}"
local cl_defolt = 0xFFD700
local cl_white = "{FFFFFF}"
local cl_red = "{FF0000}"
local cl_gold = "{FFD700}"
local cl_yellow = "{FFFF00}"
local cl_green = "{32CD32}"
local cl_lime = "{00FF00}"
local cl_orange = "{FFA500}"
local cl_orangered = "{FF4500}"
local cl_darkorange = "{FF8C00}"
local cl_blue = "{0000FF}"
local cl_navy = "{000080}"
local cl_aqua = "{00FFFF}"
local cl_teal = "{008080}"
local cl_gray = "{808080}"

update_state = false

script_version = 1.0

local update_url = "https://raw.githubusercontent.com/MironDiamond/Mafia-Assistant/main/Update.ini"
local update_path = getWorkingDirectory() .. "/Mafia Assistant/update.ini"

local script_url = "https://github.com/MironDiamond/Mafia-Assistant/raw/main/Mafia%20Assistant.luac"
local script_path = thisScript().path

hud_pos_status_f = 0
hud_pos_status = 0

imgui.Process = false
imgui.ShowCursor = false

local ImVec2 = imgui.ImVec2

-- Window
main_window_state = imgui.ImBool(false)
bmenu_window_state = imgui.ImBool(false)
kpk_window_state = imgui.ImBool(false)
hud_window_state = imgui.ImBool(false)
dw_window_state = imgui.ImBool(false)
hint_window_state = imgui.ImBool(false)
hud_pos_window_state = imgui.ImBool(false)
kpk_input_uninvite_window_state = imgui.ImBool(false)

-- buffer
local hint_text = imgui.ImBuffer(65000)
binder_text = imgui.ImBuffer(65000)
text_buffer_kpk_uninvite = imgui.ImBuffer(256)
text_buffer_accent = imgui.ImBuffer(tostring(mainIni.Accent.accent), 256)
text_buffer_prefix = imgui.ImBuffer(tostring(mainIni.Prefix.prefix), 256)
text_buffer_help = imgui.ImBuffer(tostring(mainIni.Help.help), 256)
text_buffer_scream1 = imgui.ImBuffer(tostring(mainIni.Scream.scream1), 256)
text_buffer_scream2 = imgui.ImBuffer(tostring(mainIni.Scream.scream2), 256)
text_buffer_scream3 = imgui.ImBuffer(tostring(mainIni.Scream.scream3), 256)
text_buffer_binder = imgui.ImBuffer(256)
hint_header_text = imgui.ImBuffer(256)
-- status
status_hud = imgui.ImBool(mainIni.Activate.hud)
status_accent = imgui.ImBool(mainIni.Activate.accent)
status_prefix = imgui.ImBool(mainIni.Activate.prefix)
status_timer = imgui.ImBool(mainIni.Activate.timer)
status_help = imgui.ImBool(mainIni.Activate.help)
status_w_1 = imgui.ImBool(mainIni.Weapon.w1)
status_w_2 = imgui.ImBool(mainIni.Weapon.w2)
status_w_3 = imgui.ImBool(mainIni.Weapon.w3)
status_w_4 = imgui.ImBool(mainIni.Weapon.w4)
status_w_5 = imgui.ImBool(mainIni.Weapon.w5)
status_w_6 = imgui.ImBool(mainIni.Weapon.w6)
status_w_7 = imgui.ImBool(mainIni.Weapon.w7)
status_w_8 = imgui.ImBool(mainIni.Weapon.w8)
status_ignore_1 = imgui.ImBool(mainIni.Ignore.ignore1)
status_ignore_2 = imgui.ImBool(mainIni.Ignore.ignore2)
status_ignore_3 = imgui.ImBool(mainIni.Ignore.ignore3)
status_ignore_4 = imgui.ImBool(mainIni.Ignore.ignore4)
status_ignore_5 = imgui.ImBool(mainIni.Ignore.ignore5)
status_ignore_6 = imgui.ImBool(mainIni.Ignore.ignore6)
status_ignore_7 = imgui.ImBool(mainIni.Ignore.ignore7)
status_ignore_8 = imgui.ImBool(mainIni.Ignore.ignore8)
--radio
radio_sex = imgui.ImInt(mainIni.Sex.sex)

rid = ""
rid1 = ""
rid2 = ""
rid3 = ""
recon = false
retime = -1
retimer = -1

combo_hint_select = imgui.ImInt(0)
combo_hint_str = {u8"��������� �1", u8"��������� �2", u8"��������� �3", u8"��������� �4", u8"��������� �5", u8"��������� �6", u8"��������� �7", u8"��������� �8", u8"��������� �9", u8"��������� �10"}
combo_hint_str2 = {tostring(mainIni.Hint.hint1), tostring(mainIni.Hint.hint2), tostring(mainIni.Hint.hint3), tostring(mainIni.Hint.hint4), tostring(mainIni.Hint.hint5), tostring(mainIni.Hint.hint6), tostring(mainIni.Hint.hint7), tostring(mainIni.Hint.hint8), tostring(mainIni.Hint.hint9), tostring(mainIni.Hint.hint10)}
combo_hint_select_update = -1

local hk = {}
local hotkeys = {}

sw, sh = getScreenResolution()
anim = sh - 290

chatoff_bool = 0
closestId = getClosestPlayerId
currentWeapon = -1
timer_status = 0
cursor_false = 1
time_center = -1
menu_number = -1
info_number = -1
bmenu_number = -1
kpk_number = -1
ridinput = 0
mhelp_text = -1
mhelp_accept = 0

hint_print_status = 0

Player_ID = -1
myID = -1

RP1 = -1

fontsize25 = nill

k = 1

-- Binder

local function loadImGuiHotkeys()
    local id_to_name = require("vkeys").id_to_name

    local tBlockKeys = {[VK_RETURN] = true, [VK_T] = true, [VK_F6] = true, [VK_F8] = true}
    local tBlockChar = {[116] = true, [84] = true}
    local tModKeys = {[VK_MENU] = true, [VK_SHIFT] = true, [VK_CONTROL] = true}
    local tBlockNextDown = {}

    local tHotKeyData = {
        edit = nil,
        save = {},
        lastTick = os.clock(),
        tickState = false
    }
    local tKeys = {}

    function mimgui.HotKey(name, keys, size, disabled)
        local disabled = disabled or false
        local name = tostring(name)
        local keys, bool = keys or {}, false
        local thisEdit = false

        local sKeys = hk.getKeysName(keys.v)

        if #tHotKeyData.save > 0 and tostring(tHotKeyData.save[1]) == name then
            keys.v = tHotKeyData.save[2]
            sKeys = hk.getKeysName(keys.v)
            tHotKeyData.save = {}
            bool = true
        elseif tHotKeyData.edit and tostring(tHotKeyData.edit) == name then
            thisEdit = true
            if #tKeys == 0 then
                if os.clock() - tHotKeyData.lastTick > 0.5 then
                tHotKeyData.lastTick = os.clock()
                tHotKeyData.tickState = not tHotKeyData.tickState
            end
            sKeys = tHotKeyData.tickState and "No" or " "
            else sKeys = hk.getKeysName(tKeys) end
        end
        local colText = mimgui.GetStyle().Colors[mimgui.Col.Text]
        mimgui.PushStyleColor(mimgui.Col.Button, mimgui.GetStyle().Colors[mimgui.Col.FrameBg])
        mimgui.PushStyleColor(mimgui.Col.ButtonHovered, mimgui.GetStyle().Colors[mimgui.Col.FrameBgHovered])
        mimgui.PushStyleColor(mimgui.Col.ButtonActive, mimgui.GetStyle().Colors[mimgui.Col.FrameBgActive])
        mimgui.PushStyleColor(mimgui.Col.Text, (disabled and not thisEdit) and mimgui.ImVec4(colText.x, colText.y, colText.z, 0.5) or colText)
        mimgui.PushStyleVarVec2(mimgui.StyleVar.ButtonTextAlign, mimgui.ImVec2(0.04, 0.4))
        if mimgui.Button((tostring(sKeys):len() == 0 and "No" or sKeys) .. name, size) then
            tHotKeyData.edit = name
        end
        mimgui.PopStyleVar()
        mimgui.PopStyleColor(4)
        return bool
    end

    function hk.getCurrentEdit()
        return tHotKeyData.edit ~= nil
    end

    function hk.getKeysList(bool)
        local bool = bool or false
        local tKeysList = {}
        if bool then
            for k, v in ipairs(tKeys) do
                tKeysList[k] = id_to_name(v)
            end
        else
            tKeysList = tKeys
        end
        return tKeysList
    end

    function hk.getKeysName(keys)
        if type(keys) ~= "table" then
            return false
        else
            local tKeysName = {}
            for k, v in ipairs(keys) do
                tKeysName[k] = id_to_name(v)
            end
            return table.concat(tKeysName, " + ")
        end
    end

    local function getKeyNumber(id)
        for k, v in ipairs(tKeys) do
            if v == id then
                return k
            end
        end
        return -1
    end

    local function reloadKeysList()
        local tNewKeys = {}
        for k, v in pairs(tKeys) do
            tNewKeys[#tNewKeys + 1] = v
        end
        tKeys = tNewKeys
        return true
    end

    function hk.isKeyModified(id)
        if type(id) ~= "number" then return false end
        return (tModKeys[id] or false) or (tBlockKeys[id] or false)
    end

    addEventHandler("onWindowMessage", function(msg, wparam, lparam)
        if tHotKeyData.edit and msg == 0x0102 --[[WM_CHAR]] then
            if tBlockChar[wparam] then
                consumeWindowMessage(true, true)
            end
        end
        if msg == 0x0100 --[[WM_KEYDOWN]] or msg == 0x0104 --[[WM_SYSKEYDOWN]] then
            if tHotKeyData.edit and wparam == VK_ESCAPE then
                tKeys = {}
                tHotKeyData.edit = nil
                consumeWindowMessage(true, true)
            end
            if tHotKeyData.edit and wparam == VK_BACK then
                tHotKeyData.save = {tHotKeyData.edit, {}}
                tHotKeyData.edit = nil
                consumeWindowMessage(true, true)
            end
            local num = getKeyNumber(wparam)
            if num == -1 then
                tKeys[#tKeys + 1] = wparam
                if tHotKeyData.edit then
                    if not hk.isKeyModified(wparam) then
                        tHotKeyData.save = {tHotKeyData.edit, tKeys}
                        tHotKeyData.edit = nil
                        tKeys = {}
                        consumeWindowMessage(true, true)
                    end
                end
            end
            reloadKeysList()
            if tHotKeyData.edit then
                consumeWindowMessage(true, true)
            end
        elseif msg == 0x0101 --[[WM_KEYUP]] or msg == 0x0105 --[[WM_SYSKEYUP]] then
            local num = getKeyNumber(wparam)
            if num > -1 then
                tKeys[num] = nil
            end
            reloadKeysList()
            if tHotKeyData.edit then
                consumeWindowMessage(true, true)
            end
        end
    end)
end

local hotkeys = {}

local show_window = mimgui.new.bool()
local function onStartHotkey(content)
	local positionX, positionY, positionZ = getCharCoordinates(PLAYER_PED)
    if show_window[0] then return end
    content = u8:decode(content)
			if not sampIsChatInputActive() and not sampIsDialogActive() and not main_window_state.v and not bmenu_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and not kpk_window_state.v then
    for line in content:gmatch("[^\r\n]+") do
        if line:len() > 0 then
            if line:find("^%<%d+%>$") then
                local sleep = line:match("^%<(%d+)%>$")
                wait(tonumber(sleep))
            elseif line:find("^%#") then
                local text = line:match("^%#(.*)")
								text = string.gsub(text, "{myid}", myID)
								text = string.gsub(text, "{mynick}", myNick)
								text = string.gsub(text, "{myrpnick}", myRPNick)
								text = string.gsub(text, "{myping}", myPing)
								text = string.gsub(text, "{myscore}", myScore)
								text = string.gsub(text, "{select_id}", Player_ID)
								text = string.gsub(text, "{select_nick}", Player_Nick)
								text = string.gsub(text, "{select_score}", Player_Score)
								text = string.gsub(text, "{select_ping}", Player_Ping)
								text = string.gsub(text, "{select_rpnick}", Player_RPNick)
								text = string.gsub(text, "{closest_id}", Closest_ID)
								text = string.gsub(text, "{closest_nick}", Closest_Nick)
								text = string.gsub(text, "{closest_score}", Closest_Score)
								text = string.gsub(text, "{closest_ping}", Closest_Ping)
								text = string.gsub(text, "{closest_rpnick}", Closest_RPNick)
								text = string.gsub(text, "{area}", calculateZone(positionX, positionY, positionZ))
                sampAddChatMessage(text, -1)
							elseif line:find("^%$") then
							local text = line:match("^%$(.*)")
							sampSetChatInputEnabled(true)
							text = string.gsub(text, "{myid}", myID)
							text = string.gsub(text, "{mynick}", myNick)
							text = string.gsub(text, "{myrpnick}", myRPNick)
							text = string.gsub(text, "{myping}", myPing)
							text = string.gsub(text, "{myscore}", myScore)
							text = string.gsub(text, "{select_id}", Player_ID)
							text = string.gsub(text, "{select_nick}", Player_Nick)
							text = string.gsub(text, "{select_score}", Player_Score)
							text = string.gsub(text, "{select_ping}", Player_Ping)
							text = string.gsub(text, "{select_rpnick}", Player_RPNick)
							text = string.gsub(text, "{closest_id}", Closest_ID)
							text = string.gsub(text, "{closest_nick}", Closest_Nick)
							text = string.gsub(text, "{closest_score}", Closest_Score)
							text = string.gsub(text, "{closest_ping}", Closest_Ping)
							text = string.gsub(text, "{closest_rpnick}", Closest_RPNick)
							text = string.gsub(text, "{area}", calculateZone(positionX, positionY, positionZ))
							sampSetChatInputText(text)
						elseif line:find("^%%") then
								local text = line:match("^%%(.*)")
								text = string.gsub(text, "{myid}", myID)
								text = string.gsub(text, "{mynick}", myNick)
								text = string.gsub(text, "{myrpnick}", myRPNick)
								text = string.gsub(text, "{myping}", myPing)
								text = string.gsub(text, "{myscore}", myScore)
								text = string.gsub(text, "{select_id}", Player_ID)
								text = string.gsub(text, "{select_nick}", Player_Nick)
								text = string.gsub(text, "{select_score}", Player_Score)
								text = string.gsub(text, "{select_ping}", Player_Ping)
								text = string.gsub(text, "{select_rpnick}", Player_RPNick)
								text = string.gsub(text, "{closest_id}", Closest_ID)
								text = string.gsub(text, "{closest_nick}", Closest_Nick)
								text = string.gsub(text, "{closest_score}", Closest_Score)
								text = string.gsub(text, "{closest_ping}", Closest_Ping)
								text = string.gsub(text, "{closest_rpnick}", Closest_RPNick)
								text = string.gsub(text, "{area}", calculateZone(positionX, positionY, positionZ))
								sampfuncsLog(text)
						elseif line:find("^%*") then
							takeScreen()
            else
								line = string.gsub(line, "{myid}", myID)
								line = string.gsub(line, "{mynick}", myNick)
								line = string.gsub(line, "{myrpnick}", myRPNick)
								line = string.gsub(line, "{myping}", myPing)
								line = string.gsub(line, "{myscore}", myScore)
								line = string.gsub(line, "{select_id}", Player_ID)
								line = string.gsub(line, "{select_nick}", Player_Nick)
								line = string.gsub(line, "{select_score}", Player_Score)
								line = string.gsub(line, "{select_ping}", Player_Ping)
								line = string.gsub(line, "{select_rpnick}", Player_RPNick)
								line = string.gsub(line, "{closest_id}", Closest_ID)
								line = string.gsub(line, "{closest_nick}", Closest_Nick)
								line = string.gsub(line, "{closest_score}", Closest_Score)
								line = string.gsub(line, "{closest_ping}", Closest_Ping)
								line = string.gsub(line, "{closest_rpnick}", Closest_RPNick)
								line = string.gsub(line, "{area}", calculateZone(positionX, positionY, positionZ))
                sampSendChat(line)
            end
        end
    end
	end
end

local filename = (getGameDirectory().."\\moonloader\\Mafia Assistant\\binder.json"):format(getFolderPath(0x05))

local function loadHotkeys()
    if doesFileExist(filename) then
        for line in io.lines(filename) do
            local result, data = pcall(decodeJson, line)
            if result then
                table.insert(hotkeys, data)
                if #data.keys > 0 then
                    rkeys.registerHotKey(data.keys, 1, false, function()
                        onStartHotkey(data.content)
                    end)
                end
            end
        end
    end
end

local function saveHotkeys()
    local file = io.open(filename, "w")
    for i, data in ipairs(hotkeys) do
        file:write(encodeJson(data, true))
        if #hotkeys ~= i then file:write("\n") end
    end
    file:close()
end

text = renderCreateFont('Tahoma', 15, 5)
current_hotkey = nil
keys_hotkey = {v = {}}
content_hotkey = mimgui.new.char[0x10000]()
description_hotkey = mimgui.new.char[0x100]()

local fontsize = nil
function imgui.BeforeDrawFrame()
    if fa_font == nil then
        local font_config = imgui.ImFontConfig() -- to use 'imgui.ImFontConfig.new()' on error
        font_config.MergeMode = true
        fa_font = imgui.GetIO().Fonts:AddFontFromFileTTF('moonloader/Mafia Assistant/fonts/fontawesome-webfont.ttf', 14.0, font_config, fa_glyph_ranges)
    end
		if fontsize == nil then
				fontsize = imgui.GetIO().Fonts:AddFontFromFileTTF(getFolderPath(0x14) .. '\\trebucbd.ttf', 50.0, nil, imgui.GetIO().Fonts:GetGlyphRangesCyrillic())
				fontsize2 = imgui.GetIO().Fonts:AddFontFromFileTTF(getFolderPath(0x14) .. '\\trebucbd.ttf', 18.0, nil, imgui.GetIO().Fonts:GetGlyphRangesCyrillic())
				fontsize3 = imgui.GetIO().Fonts:AddFontFromFileTTF(getFolderPath(0x14) .. '\\trebucbd.ttf', 14.5, nil, imgui.GetIO().Fonts:GetGlyphRangesCyrillic())
		end
end

function onScriptTerminate(script, quitGame)
    if thisScript() == script then
        saveHotkeys()
    end
end

-- Script

function main()
				if not isSampLoaded() or not isSampfuncsLoaded() then return end
		    while not isSampAvailable() do wait(0) end
				wait(0)
				downloadUrlToFile(update_url, update_path, function(id, status)
					local updateIni = inicfg.load(nil, update_path)
					if status == dlstatus.STATUS_ENDDOWNLOADDATA and update_state == false and updateIni ~= nil then
						local updateIni = inicfg.load(nil, update_path)
						if tonumber(updateIni.Update.version) > script_version then
							sampAddChatMessage(tag.."��������! ���������� ����� ������ �������: {FF2222}" .. tostring(updateIni.Update.version) .. "", -1)
							sampAddChatMessage(tag.."����������..", -1)
							update_state = true
						end
					end
				end)

		    sampAddChatMessage(tag .. "������ ������� �����������! �����: {80BCFF}Miron Diamond", -1)
				sampAddChatMessage(tag .. "������� ���� ������� - {80BCFF}F2", -1)
				mainIni = inicfg.load(nil, directIni)
				userscreenX, userscreenY = getScreenResolution()
				bindBMenu = mrkeys.registerHotKey(HotKeyBMenu.v, true, BMenu)
				bindKPK = mrkeys.registerHotKey(HotKeyKPK.v, true, KPK)
				bindHint = mrkeys.registerHotKey(HotKeyHint.v, true, Hint)
				bindScream = mrkeys.registerHotKey(HotKeyScream.v, true, Scream)
				bindMenu = mrkeys.registerHotKey(HotKeyMenu.v, true, Menu)
				bindRPGun = mrkeys.registerHotKey(HotKeyRPGun.v, true, RPGun)
				sampRegisterChatCommand("f", function(text) if status_prefix.v then sampSendChat('/f '..u8:decode(mainIni.Prefix.prefix)..' '..text) else sampSendChat('/f '..text) end end)
				sampRegisterChatCommand("mhelp", mhelp_command)
				sampRegisterChatCommand("select", selectID)
				sampRegisterChatCommand("cc", ClearChat)
				sampRegisterChatCommand("cancel", cancelID)
				sampRegisterChatCommand('timer', timer)
				sampRegisterChatCommand("stoptimer", stoptimer)
				sampRegisterChatCommand("assistant", Menu)
				sampRegisterChatCommand("reload", Reload)
				sampRegisterChatCommand("unload", Unload)
				sampRegisterChatCommand("rec", Reconnect)
				sampRegisterChatCommand("chatoff", Chatoff)
		    loadImGuiHotkeys()
		    loadHotkeys()
				imgui.SwitchContext()
					themes.SwitchColorTheme(1)
					thread_bmenu = lua_thread.create_suspended(thread_function_bmenu)
					thread_kpk = lua_thread.create_suspended(thread_function_kpk)
					thread_reconnect = lua_thread.create_suspended(thread_function_reconnect)
					thread_mhelp = lua_thread.create_suspended(thread_function_mhelp)
					thread_mhelp_help = lua_thread.create_suspended(thread_function_mhelp_help)

					while true do wait(0)
							if update_state then
								downloadUrlToFile(script_url, script_path, function(id, status)
									if status == dlstatus.STATUS_ENDDOWNLOADDATA then
										sampAddChatMessage(tag.."������ ������� ��������!", -1)
										thisScript():reload()
									end
								end)
								break
							end

							local sw, sh = getScreenResolution()

							getClosestPlayerId(closestId)
		--
						if status_hud.v == false and ridinput == 1 then
						renderFontDrawText(text, '{FFFFFF}��������� ID: {FF2222}' .. rid, 30, 450, 0xFFFFFFFF)
						end
		--
						currentWeapon = getCurrentCharWeapon(PLAYER_PED)
		--
							combo_hint_str2 = {tostring(mainIni.Hint.hint1), tostring(mainIni.Hint.hint2), tostring(mainIni.Hint.hint3), tostring(mainIni.Hint.hint4), tostring(mainIni.Hint.hint5), tostring(mainIni.Hint.hint6), tostring(mainIni.Hint.hint7), tostring(mainIni.Hint.hint8), tostring(mainIni.Hint.hint9), tostring(mainIni.Hint.hint10)}
		--

						if not bmenu_window_state.v and not main_window_state.v and not show_window[0] and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and not kpk_input_uninvite_window_state.v then
							if hud_pos_status == 0 then
							imgui.SwitchContext()
							themes.SwitchColorTheme(2)
							hud_window_state.v = mainIni.Activate.hud
							imgui.Process = hud_window_state.v
							end
						else
							if hud_pos_status == 0 and not dw_window_state.v then
							imgui.SwitchContext()
							themes.SwitchColorTheme(1)
							hud_window_state.v = false
						else
							themes.SwitchColorTheme(3)
						end
						end
		--
						if radio_sex.v == 1 then
							RP1 = "�"
						elseif radio_sex.v == 2 then
							RP1 = "��"
						elseif radio_sex.v == 3 then
							RP1 = "�(�)"
						end
						_, myID = sampGetPlayerIdByCharHandle(PLAYER_PED)
						if myID == -1 then
							myNick = -1
							myRPNick = -1
							myPing = -1
							myScore = -1
						else
						myNick = sampGetPlayerNickname(myID)
						myRPNick = string.gsub(myNick, "_", " ")
						myPing = sampGetPlayerPing(myID)
						myScore = sampGetPlayerScore(myID)
					end
						if Player_ID == -1 then
							Player_Nick = -1
							Player_RPNick = -1
							Player_Ping = -1
							Player_Score = -1
						else
							if sampIsPlayerConnected(Player_ID) then
						Player_Nick = sampGetPlayerNickname(Player_ID)
						Player_RPNick = string.gsub(Player_Nick, "_", " ")
						Player_Ping = sampGetPlayerPing(Player_ID)
						Player_Score = sampGetPlayerScore(Player_ID)
							end
						end
						if getClosestPlayerId() == -1 then
							Closest_ID = -1
							Closest_Nick = -1
							Closest_RPNick = -1
							Closest_Ping = -1
							Closest_Score = -1
						else
							if sampIsPlayerConnected(getClosestPlayerId()) then
							Closest_ID = getClosestPlayerId()
							Closest_Nick = sampGetPlayerNickname(getClosestPlayerId())
							Closest_RPNick = string.gsub(Closest_Nick, "_", " ")
							Closest_Ping = sampGetPlayerPing(getClosestPlayerId())
							Closest_Score = sampGetPlayerScore(getClosestPlayerId())
							end
						end
					inicfg.load(nil, directIni)
							if hud_pos_status_f == 1 then
								themes.SwitchColorTheme(2)
								hud_pos_status = 1
								main_window_state.v = false
								hud_window_state.v = true
								showCursor(true)
								cX,cY = getCursorPos()
								mainIni.cord.xCoord = cX * 1,5
								mainIni.cord.yCoord = cY * 1,5
								inicfg.save(mainIni, directIni)
							end
							if isKeyJustPressed(13) then
								if hud_pos_status == 1 then
								cX,cY = getCursorPos()
								mainIni.cord.xCoord = cX * 1,5
								mainIni.cord.yCoord = cY * 1,5
								inicfg.save(mainIni, directIni)
								showCursor(false)
													imgui.ShowCursor = false
													hud_pos_status = 0
													hud_pos_status_f = 0
												end
							end
							if isKeyJustPressed(VK_Y) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
								if mhelp_accept == 1 then
									local Nick1, Nick2, ID, X, Y = mhelp_text:match('%[F%] %(%( .+ (.+)_(.+)%[(.+)%]: %[Mafia Assistant%]: ([-0-9.]+), ([-0-9.]+)')
									setMarker(1,X,Y)
									sampAddChatMessage(tag.."����� �����������.", -1)
									mhelp_accept = 0
								end
							end
							if isKeyJustPressed(VK_N) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
								if mhelp_accept == 1 then
									sampAddChatMessage(tag.."�� ��������� �������� ���������.", -1)
									mhelp_accept = 0
								end
							end
						if isKeyJustPressed(VK_1) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 1
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_2) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 2
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_3) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 3
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_4) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 4
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_5) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 5
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_6) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 6
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_7) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 7
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_8) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 8
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_9) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 9
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_0) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1 then
							local vk_result = 0
							if rid1 == "" then
								rid1 = vk_result
							else
								if rid2 == "" then
									rid2 = vk_result
									else
										if rid3 == "" then
											rid3 = vk_result
										end
									end
							end
							rid = rid1 .. "" .. rid2 .."" .. rid3
						end
						if isKeyJustPressed(VK_OEM_PLUS) and not sampIsChatInputActive() and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
							if Player_ID == -1 then
							ridinput = 1
						end
						end
							if isKeyJustPressed(VK_BACK) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
								if rid3 ~= "" then
									rid3 = ""
								else
									if rid2 ~= "" then
										rid2 = ""
									else
										if rid1 ~= "" then
											rid1 = ""
										end
									end
								end
								rid = rid1 .. "" .. rid2 .."" .. rid3
							end
							if isKeyJustPressed(VK_OEM_MINUS) and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
								if rid1 == "" and rid2 == "" and rid3 == "" and Player_ID ~= -1 then
									sampAddChatMessage(tag.."�� ��������� �������������� � �������: {FF2222}" ..Player_Nick .. " ["..Player_ID.."]", -1)
									Player_ID = -1
									rid1 = ""
									rid2 = ""
									rid3 = ""
									rid = ""
									ridinput = 0
								else
									rid1 = ""
									rid2 = ""
									rid3 = ""
									rid = ""
								ridinput = 0
								end
							end
							if isKeyJustPressed(13) and rid ~= "" and not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] and ridinput == 1  then
								if sampIsPlayerConnected(rid) then
								Player_ID = rid
								Player_Nick = sampGetPlayerNickname(Player_ID)
								rid1 = ""
								rid2 = ""
								rid3 = ""
								rid = ""
								sampAddChatMessage(tag..'�� ������ �������������� � �������: {FF2222}'..Player_Nick..' ['.. Player_ID .. ']', -1)
														ridinput = 0
							else
								sampAddChatMessage(tag..'������ ID.', -1)
							end
							end
							if isKeyDown(VK_RBUTTON) then
			         if isKeyJustPressed(VK_MENU) then
			             local result, ped = getCharPlayerIsTargeting(PLAYER_HANDLE)
			             if result and doesCharExist(ped) then
			                 local success, id = sampGetPlayerIdByCharHandle(ped)
			                 if success then
			                     local pname = sampGetPlayerNickname(id)
			                     local pscore = sampGetPlayerScore(id)
			                     Player_ID = id
													 rid1 = ""
													 rid2 = ""
													 rid3 = ""
													 rid = ""
			                     sampAddChatMessage(tag..'�� ������ �������������� � �������: {FF2222}'..pname..' ['.. Player_ID .. ']', -1)
			                 end
			             end
			         end
			     end
				end
		    wait(-1)
end

-- Imgui

function imgui.OnDrawFrame()
	if not dw_window_state.v then
		sw, sh = getScreenResolution()
		anim = sh - 180
	end

	if not bmenu_window_state.v and not main_window_state.v and not hud_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and not kpk_input_uninvite_window_state.v then
		imgui.Process = false
	end

	if bmenu_window_state.v or kpk_window_state.v or main_window_state.v or show_window[0] or dw_window_state.v or hint_window_state.v or kpk_input_uninvite_window_state.v then
		hud_window_state.v = false
		imgui.ShowCursor = true
	end

	if hud_window_state.v then
		if cursor_false == 1 then
			showCursor(false)
			imgui.ShowCursor = false
			cursor_false = 0
		end
		local sw, sh = getScreenResolution()
		local positionX, positionY, positionZ = getCharCoordinates(PLAYER_PED)
		mainIni = inicfg.load(nil, directIni)
		inicfg.save(mainIni, directIni)
			if myID == -1 then
			else
				imgui.SetNextWindowSize(imgui.ImVec2(227, 115), imgui.Cond.FirstUseEver)
				imgui.Begin("Mafia Assistant", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
				if hud_pos_status == 1 then
				local mX, mY = getCursorPos()
        imgui.SetWindowPos(imgui.ImVec2(mX, mY))
			else
				imgui.SetWindowPos(imgui.ImVec2(mainIni.cord.xCoord, mainIni.cord.yCoord))
				end
				imgui.ShowCursor = false
				imgui.TextCenter(u8''..myNick.. " ["..myID.."] | Ping: "..myPing)
				imgui.BeginChild("##BVHS2a0020bx0284", imgui.ImVec2(200, 1), false)
				imgui.EndChild()
				imgui.Separator()
				imgui.Text(u8"�����: " .. calculateZone(positionX, positionY, positionZ))
				if Player_ID == -1 and ridinput == 0 then
				imgui.Text(u8"�����: �� ������")
				elseif ridinput == 1 then
					imgui.Text(u8"��������� ID: " .. rid)
				else
				imgui.Text(u8"�����: " .. Player_Nick .. " [" .. Player_ID .. "]")
				end
				imgui.Separator()
				imgui.CenterTextColoredRGB(os.date("{C0C0C0}%d.%m.%Y %H:%M:%S", os.time()))
				imgui.End()
			end
		end

	if main_window_state.v then
		local sw, sh = getScreenResolution()
					imgui.SetNextWindowPos(imgui.ImVec2(sw / 2, sh / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
					imgui.SetNextWindowSize(imgui.ImVec2(720, 383), imgui.Cond.FirstUseEver)
		imgui.Begin("##777Hb2829sMDis39s", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
		imgui.LockPlayer = true
			imgui.BeginChild("##isg392hSShgsi852255666", imgui.ImVec2(150, 350), false)
		img = imgui.CreateTextureFromFile(getGameDirectory() ..  "\\moonloader\\Mafia Assistant\\images\\Mafia Assistant.png")
		imgui.Image(img, imgui.ImVec2(150, 150))
		if imgui.Button(u8"�������", imgui.ImVec2(150, 35)) then
			menu_number = 1
		end
		if imgui.Button(u8"���������", imgui.ImVec2(150, 35)) then
			menu_number = 2
		end
		if imgui.Button(u8"������", imgui.ImVec2(150, 35)) then
			menu_number = 3
		end
		if imgui.Button(u8"���������", imgui.ImVec2(150, 35)) then
			menu_number = 4
		end
		if imgui.Button(u8"�������������", imgui.ImVec2(150, 35)) then
			menu_number = 5
		end
		imgui.EndChild()
		imgui.SameLine()
		imgui.BeginChild("##sug298dhiGGajjsjb2", imgui.ImVec2(545, 345), true)
		if menu_number == 1 then
			if imgui.Button(u8"����������", imgui.ImVec2(99.4, 30)) then
				info_number = 1
			end
			imgui.SameLine()
			if imgui.Button(u8"����������", imgui.ImVec2(99.4, 30)) then
				info_number = 2
			end
			imgui.SameLine()
			if imgui.Button(u8"�������", imgui.ImVec2(99.4, 30)) then
				info_number = 3
			end
			imgui.SameLine()
			if imgui.Button(u8"�������", imgui.ImVec2(99.4, 30)) then
				info_number = 4
			end
			imgui.SameLine()
			if imgui.Button(u8"����������", imgui.ImVec2(99.4, 30)) then
				info_number = 5
			end
			imgui.BeginChild("##19387xx22F", imgui.ImVec2(535, 1), false)
			imgui.EndChild()
			imgui.Separator()
			if info_number == 1 then
				imgui.BeginChild("##19387xsa2224sx22F", imgui.ImVec2(535, 10), false)
				imgui.EndChild()
				imgui.Text("")
				imgui.PushFont(fontsize)
				imgui.TextCenter("Mafia Assistant")
				 imgui.PopFont()
				 imgui.Text("")
				 imgui.PushFont(fontsize3)
				 imgui.TextCenter(u8"������ ����������� ������������� ��� ���������� ���� �� ���� �������.")
				 imgui.TextCenter(u8"��� ������� ���� �������� ��� ��� Diamond Role Play.")
				 imgui.TextCenter(u8"�����: Miron Diamond.")
				 imgui.PopFont()
				  imgui.Text("")
					imgui.Text("")
				imgui.Separator()
				imgui.BeginChild("##1NJJ293jfj272d87xx22F", imgui.ImVec2(535, 1), false)
				imgui.EndChild()
				imgui.TextCenter(u8"���������� ���? ����� ��� ����:")
				imgui.BeginChild("##19387xsa2224sx22FRAN2241", imgui.ImVec2(535, 3), false)
				imgui.EndChild()
				imgui.Button(fa.ICON_DIAMOND .. u8" Diamond Role Play", imgui.ImVec2(170, 30))
				imgui.SameLine()
				if imgui.Button(fa.ICON_VK .. u8" VK", imgui.ImVec2(170, 30)) then os.execute('explorer "https://vk.com/miron_diamond"') end
				imgui.SameLine()
				imgui.Button(fa.ICON_GLOBE .. u8" Blast Hack", imgui.ImVec2(173, 30))
				imgui.BeginChild("##1NJ00J29387xx22F", imgui.ImVec2(535, 5), false)
				imgui.EndChild()
				imgui.Separator()
				imgui.CenterTextColoredRGB(u8"{C0C0C0}Version: 1.0")
			elseif info_number == 2 then
				imgui.BeginChild("##xrUSUur201Sl+", imgui.ImVec2(529, 290), false)
				imgui.BeginChild("##09sh28S7MKoper27dD", imgui.ImVec2(535, 1), false)
				imgui.EndChild()
				if imgui.Button("{myid}", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText("{myid}")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ��� id.")
				if imgui.Button("{mynick}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{mynick}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ��� ���.")
				if imgui.Button("{myrpnick}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{myrpnick}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8'������ ��� ��� ��� "_".')
				if imgui.Button("{myping}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{myping}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ��� ����.")
				if imgui.Button("{myscore}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{myscore}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ��� �������.")
				if imgui.Button("{select_id}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{select_id}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ id ������ � ������� �� ����������������.")
				if imgui.Button("{select_nick}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{select_nick}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ��� ������ � ������� �� ����������������.")
				if imgui.Button("{select_rpnick}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{select_rpnick}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8'������ ��� ������ � ������� �� ���������������� ��� "_".')
				if imgui.Button("{select_score}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{select_score}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ������� ������ � ������� �� ����������������.")
				if imgui.Button("{select_ping}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{select_ping}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ���� ������ � ������� �� ����������������.")
				if imgui.Button("{closest_id}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{closest_id}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ id ���������� ������.")
				if imgui.Button("{closest_nick}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{closest_nick}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ��� ���������� ������.")
				if imgui.Button("{closest_rpnick}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{closest_rpnick}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8'������ ��� ���������� ������ ��� "_".')
				if imgui.Button("{closest_score}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{closest_score}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ������� ���������� ������.")
				if imgui.Button("{closest_ping}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{closest_ping}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ���� ���������� ������.")
				if imgui.Button("{area}", imgui.ImVec2(120, 20)) then
					imgui.LogToClipboard()
					imgui.LogText("{area}")
					imgui.LogFinish()
					printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ ����� � ������� �� ����������.")
				imgui.EndChild()
			elseif info_number == 3 then
				imgui.BeginChild("##xrUSUur201Sl+", imgui.ImVec2(529, 290), false)
				imgui.BeginChild("##09sh28S7MKoper27dD", imgui.ImVec2(535, 1), false)
				imgui.EndChild()
				if imgui.Button(u8"#", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"#")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"��������� ��������� � ��������� ���.")
				if imgui.Button(u8"$", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"$")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"��������� ��������� � ���(F6).")
				if imgui.Button(u8"<>", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"<>")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"�������� � �������������.")
				if imgui.Button(u8"*", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"*")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������� ��������.")
				if imgui.Button(u8"%", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"%")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"��������� ��������� � ������� SAMPFUNCS.")
				imgui.EndChild()
			elseif info_number == 4 then
				imgui.BeginChild("##xrUSUur201Sl+", imgui.ImVec2(529, 290), false)
				imgui.BeginChild("##09sh28S7MKoper27dD", imgui.ImVec2(535, 1), false)
				imgui.EndChild()
				if imgui.Button(u8"/assistant", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/assistant")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������� ���� �������.")
				if imgui.Button(u8"/reload", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/reload")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������������� ������.")
				if imgui.Button(u8"/unload", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/unload")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"��������� ������.")
				if imgui.Button(u8"/select", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/select")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"������ �������������� � �������.")
				if imgui.Button(u8"/cancel", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/cancel")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"��������� �������������� � �������.")
				if imgui.Button(u8"/timer", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/timer")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"���������� ������.")
				if imgui.Button(u8"/stoptimer", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/stoptimer")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"���������� ������.")
				if imgui.Button(u8"/cc", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/cc")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"�������� ���.")
				if imgui.Button(u8"/rec", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/rec")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"��������������� � �������.")
				if imgui.Button(u8"/chatoff", imgui.ImVec2(120, 20)) then
				imgui.LogToClipboard()
				imgui.LogText(u8"/chatoff")
				imgui.LogFinish()
				printString("~w~COPPIED", 1500)
				end
				imgui.SameLine()
				imgui.Text(u8"��������� ���.") ShowHelpMarker("��� ��������� ��������� ������� ����� ������")
				imgui.ButtonDisabled(u8"/phone", imgui.ImVec2(120, 20))
				imgui.SameLine()
				imgui.Text(u8"� ����������..")
				imgui.EndChild()
			elseif info_number == 5 then
				imgui.BeginChild("##Jsb2092h60SFFS", imgui.ImVec2(529, 290), false)
				imgui.CenterTextColoredRGB("{FFD700}07.10.2020")
				imgui.Separator()
				imgui.TextCenter("")
				imgui.CenterTextColoredRGB("- ����� �������.")
				imgui.TextCenter("")
				imgui.Separator()
				imgui.EndChild()
			end
		elseif menu_number == 2 then
			mainIni = inicfg.load(nil, directIni)
			imgui.Columns("3", "##HsbI294dXBBsDF", false)
			imgui.Text(u8"��� ������:")
			imgui.PushItemWidth(170)
			imgui.InputText("        ", text_buffer_accent)
			imgui.PopItemWidth()
			imgui.PushItemWidth(170)
			imgui.Text(u8"��� ��� � �����:")
			imgui.InputText("              ", text_buffer_prefix)
			imgui.PopItemWidth()
			imgui.NextColumn()
			imgui.NextColumn()
			imgui.Text(u8"��� ���:")
			imgui.RadioButton(u8"�������", radio_sex, 1)
			imgui.RadioButton(u8"�������", radio_sex, 2)
			imgui.RadioButton(u8"���������", radio_sex, 3)
			imgui.Columns("1", " ", false)
			imgui.BeginChild("##B7274dS0XCS", imgui.ImVec2(535, 1), false)
			imgui.EndChild()
			imgui.Separator()
			imgui.BeginChild("##19387xx22F", imgui.ImVec2(535, 1), false)
			imgui.EndChild()
			imgui.Columns("1", "##H2bd6098sBVBBV", false)
			imgui.Columns("3", "##8vud3SHSHS", false)
			imgui.Checkbox(u8"�������� �������", status_hud)
			imgui.Checkbox(u8"�������� ������", status_accent)
			imgui.Checkbox(u8"�������� ��� � �����", status_prefix)
			imgui.NextColumn()
			imgui.NextColumn()
			if imgui.Button(fa.ICON_PENCIL, imgui.ImVec2(20, 20)) then
				hud_pos_status_f = 1
			end
			imgui.SameLine()
			imgui.Text(u8"�������� �����")
			imgui.Checkbox(u8" ������ �� �������", status_timer)
			imgui.Checkbox(u8" ���� /mhelp", status_help) ShowHelpMarker("�������� ������ ��������,\n�� �� ������� �������� ���������� �������\n������� ����� ���������� /mhelp")
			imgui.Columns("1", "##Usb3bZZnt5", false)
			imgui.BeginChild("##097MKoper27dD", imgui.ImVec2(535, 1), false)
			imgui.EndChild()
			imgui.Separator()
			imgui.BeginChild("##98gh0652S2BB", imgui.ImVec2(535, 1), false)
			imgui.EndChild()
			imgui.Text(u8"�������� ������ ������� ����� ����������:")
			imgui.Columns("4", "##H27y2tdBUHapl55", false)
			imgui.Checkbox(u8"����", status_w_1) ShowHelpMarker("��� �� ��������� �� ������ � ������")
			imgui.Checkbox(u8"Desert Eagle", status_w_2)
			imgui.NextColumn()
			imgui.Checkbox(u8"Shotgun", status_w_3)
			imgui.Checkbox(u8"MP5", status_w_4)
			imgui.NextColumn()
			imgui.Checkbox(u8"M4A1", status_w_5)
			imgui.Checkbox(u8"AK47", status_w_6)
			imgui.NextColumn()
			imgui.Checkbox(u8"Rifle", status_w_7)
			imgui.Checkbox(u8"Sniper Rifle", status_w_8)
			imgui.Columns("1", " ", false)
			imgui.BeginChild("##UY2v94760foP", imgui.ImVec2(535, 1), false)
			imgui.EndChild()
			imgui.Separator()
			imgui.BeginChild("##JJ258xAS", imgui.ImVec2(535, 7), false)
			imgui.EndChild()
			imgui.TextCenter(u8"��������� ��� ������ � ������:") ShowHelpMarker("��������� ������� ����� ���������� � /f ��� �������� /mhelp")
			imgui.BeginChild("##Iu2b983MMMmn", imgui.ImVec2(535, 8), false)
			imgui.EndChild()
			imgui.PushItemWidth(530)
			imgui.InputText("##872bSSA800023", text_buffer_help)
			imgui.PopItemWidth()
			mainIni.Sex.sex = radio_sex.v
			mainIni.Accent.accent = text_buffer_accent.v
		 	mainIni.Prefix.prefix = text_buffer_prefix.v
			mainIni.Help.help = text_buffer_help.v
			mainIni.Activate.hud = status_hud.v
			mainIni.Activate.accent = status_accent.v
			mainIni.Activate.prefix = status_prefix.v
			mainIni.Activate.timer = status_timer.v
			mainIni.Activate.help = status_help.v
			mainIni.Weapon.w1 = status_w_1.v
			mainIni.Weapon.w2 = status_w_2.v
			mainIni.Weapon.w3 = status_w_3.v
			mainIni.Weapon.w4 = status_w_4.v
			mainIni.Weapon.w5 = status_w_5.v
			mainIni.Weapon.w6 = status_w_6.v
			mainIni.Weapon.w7 = status_w_7.v
			mainIni.Weapon.w8 = status_w_8.v

			 inicfg.save(mainIni, directIni)
		elseif menu_number == 3 then
			imgui.BeginChild("##Jn882dpOKsz3sc29ns", imgui.ImVec2(529, 307), true)
			imgui.Columns(3, nil, false)
			imgui.SetColumnWidth(-1, 25)
			imgui.CenterColumnText(u8"�")
			imgui.NextColumn()
			imgui.VerticalSeparator()
			imgui.CenterColumnText(u8"���������")
			imgui.NextColumn()
			imgui.VerticalSeparator()
			imgui.CenterColumnText(u8"��������")
			imgui.NextColumn()
			imgui.Separator()
			for id, data in ipairs(hotkeys) do
					local desc = data.description
					local keyname = hk.getKeysName(data.keys)
					if imgui.Selectable(tostring(id), current_hotkey == id, imgui.SelectableFlags.SpanAllColumns) then
							current_hotkey = id
					end
					imgui.NextColumn()
					imgui.CenterColumnText(keyname:len() > 0 and keyname or u8"�")
					imgui.NextColumn()
					imgui.CenterColumnText(desc:len() > 0 and desc or u8"�")
					imgui.NextColumn()
			end
			imgui.EndChild()
			if imgui.Button(fa.ICON_PENCIL_SQUARE_O .. u8" �������", imgui.ImVec2(170, 20)) then
				table.insert(hotkeys, {keys = {}, content = "", description = ""})
				current_hotkey = #hotkeys
				local hotkey = hotkeys[current_hotkey]
				keys_hotkey.v = hotkey.keys
				HotKeyBinder = {
					v = {}
				}
				text_buffer_binder.v = ""
				binder_text.v = ""
				imgui.OpenPopup("")
			end
			imgui.SameLine()
			if imgui.Button(fa.ICON_COG .. u8" ��������", imgui.ImVec2(173, 20)) then
				 if current_hotkey then
				local hotkey = hotkeys[current_hotkey]
				text_buffer_binder.v = hotkey.description
				binder_text.v = hotkey.content
				HotKeyBinder.v = hotkey.keys
				imgui.OpenPopup("")
			end
			end
			imgui.SameLine()
			if imgui.Button(fa.ICON_TRASH .. u8" �������", imgui.ImVec2(170, 20)) then
				if current_hotkey then
				table.remove(hotkeys, current_hotkey)
				current_hotkey = nil
			end
			end

			if imgui.BeginPopupModal(u8"",_, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove) then
				imgui.SetWindowSize(imgui.ImVec2(520, 320))
				imgui.Columns(2, nil, false)
				imgui.SetColumnWidth(-1, 110)
				imgui.Text(u8" ���������:")
				imgui.NextColumn()
				imgui.Text(u8"��������:")
				imgui.Columns()
				if imgui.HotKey("##BB57125585sb78Kjs0n", HotKeyBinder, tLastKeys, 100) then
				end
				imgui.SameLine()
				imgui.PushItemWidth(396)
				imgui.InputText("##MjjjN38285dDbC", text_buffer_binder)
				imgui.PopItemWidth()
				imgui.InputTextMultiline('##Ibs2dsfsb3828288fKIA', binder_text, imgui.ImVec2(504, 220))
				if imgui.Button(fa.ICON_FLOPPY_O .. u8" ���������", imgui.ImVec2(248, 20)) then
					hotkey = hotkeys[current_hotkey]
					hotkey.keys = HotKeyBinder.v
					hotkey.content = binder_text.v
					hotkey.description = text_buffer_binder.v
					if #hotkey.keys > 0 then
							rkeys.registerHotKey(hotkey.keys, 1, false, function()
									onStartHotkey(hotkey.content)
							end)
					end
					imgui.CloseCurrentPopup()
				end
				imgui.SameLine()
				if imgui.Button(fa.ICON_TIMES_CIRCLE .. u8" �������", imgui.ImVec2(248, 20)) then
					imgui.CloseCurrentPopup()
				end
				 imgui.EndPopup()
    end
		elseif menu_number == 4 then
				mainIni = inicfg.load(nil, directIni)
				imgui.InputText(u8'�������� ���������', hint_header_text)
				imgui.InputTextMultiline('##Ibs2828288fKIA', hint_text, imgui.ImVec2(529, 283))
				if imgui.Button(fa.ICON_FLOPPY_O .. u8" ���������", imgui.ImVec2(150, 20)) then
					if hint_header_text.v > "0" then
					hint_print_status = 1
				if combo_hint_select.v == 0 then
					hintid = "1"
					mainIni.Hint.hint1 = hint_header_text.v
				elseif combo_hint_select.v == 1 then
					hintid = "2"
					mainIni.Hint.hint2 = hint_header_text.v
				elseif combo_hint_select.v == 2 then
					hintid = "3"
					mainIni.Hint.hint3 = hint_header_text.v
				elseif combo_hint_select.v == 3 then
					hintid = "4"
					mainIni.Hint.hint4 = hint_header_text.v
				elseif combo_hint_select.v == 4 then
					hintid = "5"
					mainIni.Hint.hint5 = hint_header_text.v
				elseif combo_hint_select.v == 5 then
					hintid = "6"
					mainIni.Hint.hint6 = hint_header_text.v
				elseif combo_hint_select.v == 6 then
					hintid = "7"
					mainIni.Hint.hint7 = hint_header_text.v
				elseif combo_hint_select.v == 7 then
					hintid = "8"
					mainIni.Hint.hint8 = hint_header_text.v
				elseif combo_hint_select.v == 8 then
					hintid = "9"
					mainIni.Hint.hint9 = hint_header_text.v
				elseif combo_hint_select.v == 9 then
					hintid = "10"
					mainIni.Hint.hint10 = hint_header_text.v
				end
					inicfg.save(mainIni, directIni)
					file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint"..hintid..".txt", "w")
					file:write(hint_text.v) --����� ������ ����� ���������� ����
					file:close()
					sampAddChatMessage(tag.."�� ��������� ��������� {FF2222}�"..hintid.."{FFFFFF} � ���������: {FF2222}" ..u8:decode(hint_header_text.v), -1)
			else
				sampAddChatMessage(tag.."������� �������� ���������.", -1)
						end
			end
				imgui.SameLine()
				imgui.PushItemWidth(213)
				imgui.Combo('##ERR284200csA', combo_hint_select, combo_hint_str, #combo_hint_str)
				imgui.PopItemWidth()
				imgui.SameLine()
				if imgui.Button(fa.ICON_TRASH .. u8" �������", imgui.ImVec2(150, 20)) then
					hint_print_status = 1
				if combo_hint_select.v == 0 then
					hintid = "1"
					mainIni.Hint.hint1 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 1 then
					hintid = "2"
					mainIni.Hint.hint2 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 2 then
					hintid = "3"
					mainIni.Hint.hint3 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 3 then
					hintid = "4"
					mainIni.Hint.hint4 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 4 then
					hintid = "5"
					mainIni.Hint.hint5 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 5 then
					hintid = "6"
					mainIni.Hint.hint6 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 6 then
					hintid = "7"
					mainIni.Hint.hint7 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 7 then
					hintid = "8"
					mainIni.Hint.hint8 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 8 then
					hintid = "9"
					mainIni.Hint.hint9 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				elseif combo_hint_select.v == 9 then
					hintid = "10"
					mainIni.Hint.hint10 = ""
					inicfg.save(mainIni, directIni)
					hint_header_text.v = ""
				end
					file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint"..hintid..".txt", "w")
					file:write("") --����� ������ ����� ���������� ����
					file:close()
					hint_text.v = ""
					sampAddChatMessage(tag.."�� ������� ��������� {FF2222}�"..hintid.."{FFFFFF}.", -1)
				end
				updateHint()
		elseif menu_number == 5 then
			imgui.BeginChild("##Jn882dpOKsz3sc29ns", imgui.ImVec2(535, 1), false)
			imgui.EndChild()
			imgui.Columns("2", "##99209SSF27b55", false)
			if imgui.HotKey("##b2999hGhhhGSd", HotKeyMenu, tLastKeys, 100) then
				mrkeys.changeHotKey(bindMenu, HotKeyMenu.v)
				mainIni.HotKey.bindMenu = encodeJson(HotKeyMenu.v)
				inicfg.save(mainIni, directIni)
			end
			imgui.SameLine()
			imgui.Text(u8"���� �������")
			if imgui.HotKey("##Un29uusu6908S", HotKeyHint, tLastKeys, 100) then
				mrkeys.changeHotKey(bindHint, HotKeyHint.v)
				mainIni.HotKey.bindHint = encodeJson(HotKeyHint.v)
				inicfg.save(mainIni, directIni)
			end
			imgui.SameLine()
			imgui.Text(u8"���� ���������")
			if imgui.HotKey("##Gu2738fdBS973", HotKeyRPGun, tLastKeys, 100) then
				mrkeys.changeHotKey(bindRPGun, HotKeyRPGun.v)
				mainIni.HotKey.bindRPGun = encodeJson(HotKeyRPGun.v)
				inicfg.save(mainIni, directIni)
			end
			imgui.SameLine()
			imgui.Text(u8"��������� ������") ShowHelpMarker("�� �������� ������� ������ � ����������")
			imgui.NextColumn()
			if imgui.HotKey("##Nijs3432IUGssgs7", HotKeyScream, tLastKeys, 100) then
				mrkeys.changeHotKey(bindScream, HotKeyScream.v)
				mainIni.HotKey.bindScream = encodeJson(HotKeyScream.v)
				inicfg.save(mainIni, directIni)
			end
			imgui.SameLine()
			imgui.Text(u8"��������")
			if imgui.HotKey("##BuuhgvWR78Kjs0n", HotKeyBMenu, tLastKeys, 100) then
				mrkeys.changeHotKey(bindBMenu, HotKeyBMenu.v)
				mainIni.HotKey.bindBMenu = encodeJson(HotKeyBMenu.v)
				inicfg.save(mainIni, directIni)
			end
			imgui.SameLine()
			imgui.Text(u8"���� ��������")
			if imgui.HotKey("##80Sb2828fhnK0o", HotKeyKPK, tLastKeys, 100) then
				mrkeys.changeHotKey(bindKPK, HotKeyKPK.v)
				mainIni.HotKey.bindKPK = encodeJson(HotKeyKPK.v)
				inicfg.save(mainIni, directIni)
			end
			imgui.SameLine()
			imgui.Text(u8"��� �������� �������")
			imgui.BeginChild("##888Jn23sBC2pz329noh", imgui.ImVec2(535, 1), false)
			imgui.EndChild()
			imgui.Separator()
			imgui.Columns("1", "##Usyka2bd88v56K7j", false)
						imgui.BeginChild("##JnsBHNNS2s224329ns", imgui.ImVec2(535, 1), false)
						imgui.EndChild()
						imgui.Text(u8"�������� �1:")
									imgui.PushItemWidth(530)
									imgui.InputText("##IT2s8nERmc80da2", text_buffer_scream1)
									imgui.PopItemWidth()
						imgui.Text(u8"�������� �2:")
									imgui.PushItemWidth(530)
									imgui.InputText("##2IT2s8nERmc802dddfrd", text_buffer_scream2)
									imgui.PopItemWidth()
						imgui.Text(u8"�������� �3:")
									imgui.PushItemWidth(530)
									imgui.InputText("##3IT222s8nERgmc802", text_buffer_scream3)
									imgui.PopItemWidth()
						imgui.BeginChild("##JnsBCpbsz329ns", imgui.ImVec2(535, 1), false)
						imgui.EndChild()
						imgui.Separator()
						imgui.BeginChild("##JnsBCpbsz3sc29ns", imgui.ImVec2(535, 4), false)
						imgui.EndChild()
			imgui.Columns("1", "##Usyka288v56K7nsj", false)
			imgui.Columns("2", "##U288v56K7jKKK", false)
			imgui.Checkbox(u8"��������� ����� �����", status_ignore_1)
			imgui.Checkbox(u8"��������� OOC ����� �����", status_ignore_2)
			imgui.Checkbox(u8"��������� ����������", status_ignore_3)
			imgui.Checkbox(u8"��������� ���. �������", status_ignore_4)
			imgui.NextColumn()
			imgui.Checkbox(u8"��������� ���������� ������", status_ignore_5)
			imgui.Checkbox(u8"��������� ���������� �������", status_ignore_6)
			imgui.Checkbox(u8"��������� ���������� �����������", status_ignore_7)
			imgui.Checkbox(u8"��������� �������� ��������������", status_ignore_8)
			mainIni.Scream.scream1 = text_buffer_scream1.v
			mainIni.Scream.scream2 = text_buffer_scream2.v
			mainIni.Scream.scream3 = text_buffer_scream3.v
			mainIni.Ignore.ignore1 = status_ignore_1.v
			mainIni.Ignore.ignore2 = status_ignore_2.v
			mainIni.Ignore.ignore3 = status_ignore_3.v
			mainIni.Ignore.ignore4 = status_ignore_4.v
			mainIni.Ignore.ignore5 = status_ignore_5.v
			mainIni.Ignore.ignore6 = status_ignore_6.v
			mainIni.Ignore.ignore7 = status_ignore_7.v
			mainIni.Ignore.ignore8 = status_ignore_8.v
			inicfg.save(mainIni, directIni)
			end
		imgui.EndChild()
		imgui.End()
		end

	if bmenu_window_state.v then
		local sw, sh = getScreenResolution()
					imgui.SetNextWindowPos(imgui.ImVec2(sw / 2, sh / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
					imgui.SetNextWindowSize(imgui.ImVec2(280, 270), imgui.Cond.FirstUseEver)
		imgui.Begin("##oiud2288206dSF6F", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
		imgui.Columns()
		imgui.BeginChild("##Usg287sb5065Sgvv", imgui.ImVec2(264, 253), true)
		if imgui.Button(u8"������� ������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 1
		bmenur()
		end
		if imgui.Button(u8"������ ����� �� ������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 2
		bmenur()
		end
		if imgui.Button(u8"������� ������ �� �����", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 3
		bmenur()
		end
		if imgui.Button(u8"�������� ������ � ���������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 4
		bmenur()
		end
		if imgui.Button(u8"�������� ���� ������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 5
		bmenur()
		end
		if imgui.Button(u8"�������� ������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 6
		bmenur()
		end
		if imgui.Button(u8"��������� ������ ������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 7
		bmenur()
		end
		if imgui.Button(u8"��������� ������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 8
		bmenur()
		end
		if imgui.Button(u8"C���� ����� � ������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 9
		bmenur()
		end
		if imgui.Button(u8"�������� ���� � ������", imgui.ImVec2(-0.1, 0)) then
		bmenu_number = 10
		bmenur()
		end
		imgui.EndChild()
		imgui.End()
	end

	if kpk_window_state.v then
		local sw, sh = getScreenResolution()
					imgui.SetNextWindowPos(imgui.ImVec2(sw / 2, sh / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
					imgui.SetNextWindowSize(imgui.ImVec2(280, 270), imgui.Cond.FirstUseEver)
		imgui.Begin("##idn50Bs605JhHt", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
		imgui.Columns()
		imgui.BeginChild("##sib8252560SDF", imgui.ImVec2(264, 253), true)
		if imgui.Button(u8"������� ���� ������", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 1
		kpkr()
		end
		if imgui.Button(u8"������� ������", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 2
		kpkr()
		end
		if imgui.Button(u8"������� ������", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 3
		kpkr()
		end
		if imgui.Button(u8"���������� ���� ������", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 4
		kpkr()
		end
		if imgui.Button(u8"���������� ���� ������", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 5
		kpkr()
		end
		if imgui.Button(u8"��������/������ ������ �� �/�", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 6
		kpkr()
		end
		if imgui.Button(u8"��������� ������ � �/�", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 7
		kpkr()
		end
		if imgui.Button(u8"�������� �����������", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 8
		kpkr()
		end
		if imgui.Button(u8"������������ ����������", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 9
		kpkr()
		end
		if imgui.Button(u8"������ ���� �����������", imgui.ImVec2(-0.1, 0)) then
		kpk_number = 10
		kpkr()
		end
		imgui.EndChild()
		imgui.End()
	end

	if dw_window_state.v then
		local sw, sh = getScreenResolution()
		if anim ~= 486 then
		anim = anim - 3
		end
		local style = imgui.GetStyle()
		style.FrameRounding = 50
		imgui.SetWindowPos(imgui.ImVec2(sw - 200, anim))
		imgui.Begin("##duB258vj88165041", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
		imgui.SetWindowPos(imgui.ImVec2(sw - 200, anim))
		imgui.Text(fa.ICON_COMMENT_O .."						" .. fa.ICON_WIFI .. " " .. fa.ICON_SIGNAL .. "  " .. fa.ICON_BATTERY_THREE_QUARTERS)
		imgui.Separator()
		imgui.Columns("##UIsg325160sdfvDWvix", "1", "false")
		imgui.Text("")
		imgui.PushFont(fontsize)
		imgui.TextCenter(os.date("%H:%M", os.time()))
		 imgui.PopFont()
		 imgui.PushFont(fontsize2)
		 imgui.TextCenter(os.date("%d.%m", os.time()))
			imgui.PopFont()
		 		imgui.Text("")
						imgui.Text("")
								imgui.Text("")
										imgui.Text("")
												imgui.Text("")
		 imgui.Button(fa.ICON_PHONE, imgui.ImVec2(35, 35))
		 imgui.SameLine()
		 imgui.Button(fa.ICON_ADDRESS_BOOK, imgui.ImVec2(35, 35))
		 imgui.SameLine()
		 imgui.Button(fa.ICON_CAMERA, imgui.ImVec2(35, 35))
		 imgui.SameLine()
		 imgui.Button(fa.ICON_POWER_OFF, imgui.ImVec2(35, 35))
		imgui.End()
	end

	if hint_window_state.v then
			imgui.SetNextWindowPos(imgui.ImVec2(sw / 2, sh / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
								imgui.SetNextWindowSize(imgui.ImVec2(600, 500), imgui.Cond.FirstUseEver)
			mainIni = inicfg.load(nil, directIni)
			if combo_hint_select.v == 0 then
			imgui.Begin("Mafia Assistant##sn284388SsSFA1", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
			file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint1.txt", "r")
			hint_text.v= file:read('*a')
			file:close()
			elseif combo_hint_select.v == 1 then
				imgui.Begin("Mafia Assistant##sn284388SSFA2", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
				file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint2.txt", "r")
				hint_text.v= file:read('*a')
				file:close()
			elseif combo_hint_select.v == 2 then
					imgui.Begin("Mafia Assistant##sn284388SSFA3", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
					file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint3.txt", "r")
					hint_text.v= file:read('*a')
					file:close()
				elseif combo_hint_select.v == 3 then
						imgui.Begin("Mafia Assistant##sn284388SSFA4", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
						file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint4.txt", "r")
						hint_text.v= file:read('*a')
						file:close()
					elseif combo_hint_select.v == 4 then
							imgui.Begin("Mafia Assistant##sn284388SSFA5", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
							file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint5.txt", "r")
							hint_text.v= file:read('*a')
							file:close()
						elseif combo_hint_select.v == 5 then
								imgui.Begin("Mafia Assistant##sn284388SSFA6", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
								file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint6.txt", "r")
								hint_text.v= file:read('*a')
								file:close()
							elseif combo_hint_select.v == 6 then
									imgui.Begin("Mafia Assistant##sn284388SSFA7", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
									file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint7.txt", "r")
									hint_text.v= file:read('*a')
									file:close()
								elseif combo_hint_select.v == 7 then
										imgui.Begin("Mafia Assistant##sn284388SSFA8", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
										file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint8.txt", "r")
										hint_text.v= file:read('*a')
										file:close()
									elseif combo_hint_select.v == 8 then
											imgui.Begin("Mafia Assistant##sn284388SSFA9", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
											file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint9.txt", "r")
											hint_text.v= file:read('*a')
											file:close()
										elseif combo_hint_select.v == 9 then
												imgui.Begin("Mafia Assistant##sn284388SSFA10", imgui.WindowFlags.NoResize, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove)
												file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint10.txt", "r")
												hint_text.v= file:read('*a')
												file:close()
			end
			imgui.PushItemWidth(584)
			imgui.Combo('##Ishb386065d1fgiuGGsb4', combo_hint_select, combo_hint_str2, #combo_hint_str2)
			imgui.PopItemWidth()
			imgui.BeginChild("##XBCBIT266C0Heati1nt", imgui.ImVec2(584, 440), true)
			imgui.TextColoredRGB(hint_text.v)
			imgui.EndChild()
			imgui.End()
	end

	if kpk_input_uninvite_window_state.v then
		local sw, sh = getScreenResolution()
					imgui.SetNextWindowPos(imgui.ImVec2(sw / 2, sh / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
					imgui.SetNextWindowSize(imgui.ImVec2(330, 140), imgui.Cond.FirstUseEver)


		imgui.Begin("Mafia Assistant##Sol4jidbdb92s", main_window_state.v, imgui.WindowFlags.NoResize + imgui.WindowFlags.NoMove + imgui.WindowFlags.NoCollapse)
		imgui.TextCenter(u8"������� ������� ����������:")
		imgui.Text(u8"")
		imgui.SetCursorPosX((imgui.GetWindowWidth() - 50) / 5)
		imgui.InputText(u8'', text_buffer_kpk_uninvite)
		imgui.Text(u8"")
		imgui.SetCursorPosX((imgui.GetWindowWidth() - 75) / 3.1)
		if imgui.Button(u8"�������", ImVec2(75, 20)) then
			sampSendChat(u8:decode("/uninvite "..Player_ID.." ".. text_buffer_kpk_uninvite.v .. "" ))
			kpk_window_state.v = false
			kpk_input_uninvite_window_state.v = false
		end

		imgui.SameLine()
		if imgui.Button(u8"������", ImVec2(75, 20))  then
			kpk_window_state.v = not kpk_window_state.v
			kpk_input_uninvite_window_state.v = not kpk_input_uninvite_window_state.v
		end
		imgui.End()
	end
end

-- Threads

kpkr = function()
	thread_kpk:run()
end

bmenur = function()
	thread_bmenu:run()
end

mhelp = function()
	thread_mhelp:run()
end

mhelp_help = function()
	thread_mhelp_help:run()
end

reconnectr = function()
	thread_reconnect:run()
end

-- Threads function

function thread_function_mhelp()
	wait(10)
	local mainIni = inicfg.load(nil, directIni)
	if mhelp_accept == 0 and mainIni.Activate.help == true then
	local Nick1, Nick2, ID, X, Y = mhelp_text:match('%[F%] %(%( .+ (.+)_(.+)%[(.+)%]: %[Mafia Assistant%]: ([-0-9.]+), ([-0-9.]+)')
	if tostring(ID) ~= tostring(myID) then
	sampAddChatMessage(tag.."����� {FFFFFF}"..Nick1.." "..Nick2.." ["..ID.."]{FFFFFF} ����� ��������� ������ ������������.", -1)
	sampAddChatMessage(tag.."������� - {00FF00}Y{FFFFFF} | ��������� - {FF0000}N{FFFFFF}", -1)
	mhelp_accept = 1
end
	end
end

function thread_function_bmenu()
	if Player_ID == -1 then sampAddChatMessage(tag .. "������! �� �� � ��� �� ����������������.", -1)
	else
	if bmenu_number == 1 then
	sampSendChat("/me ������ �������, ������"..RP1.." ���� ������, ����� ���� �����"..RP1.." �� �� ������� ����")
	wait(500)
	sampSendChat("/tie " .. Player_ID)
	bmenu_number = -1

	elseif bmenu_number == 2 then
		sampSendChat("/me ������ �����, ����"..RP1.." ��� �� ������ ������")
		wait(500)
		sampSendChat("/bag " .. Player_ID)
		bmenu_number = -1

	elseif bmenu_number == 3 then
		sampSendChat("/me ����������� �� �������, ����"..RP1.." ������ �� �����")
		wait(500)
		sampSendChat("/hold " .. Player_ID)
		bmenu_number = -1

	elseif bmenu_number == 4 then
		sampSendChat("/me ������ ����� ����������, �������"..RP1.." ������ ������")
		wait(500)
		sampSendChat("/push " .. Player_ID)
		bmenu_number = -1

	elseif bmenu_number == 5 then
		sampSendChat("/me ������ ����, ������"..RP1.." ��� � ��� ������")
		wait(500)
		sampSendChat("/gag " .. Player_ID)
		bmenu_number = -1

	elseif bmenu_number == 6 then
		sampSendChat("/me ������"..RP1.." ������ � ������� ���, ����� ���� ������"..RP1.." � ������� ����� � � ������� ���")
		wait(500)
		sampSendChat("/frisk " .. Player_ID)
		bmenu_number = -1

	elseif bmenu_number == 7 then
		sampSendChat("/me �������� �������, ��������"..RP1.." ������")
		wait(500)
		sampSendChat("/unhold " .. Player_ID)
		bmenu_number = -1

	elseif bmenu_number == 8 then
		sampSendChat("/me �������� ������� � ��� ������, ������"..RP1.." � ���� � ������")
		wait(500)
		sampSendChat("/untie " .. Player_ID)
		bmenu_number = -1

	elseif bmenu_number == 9 then
		sampSendChat("/me ���� ����� � ������ ������, ������"..RP1.." ��� ���� � ������ ������")
		wait(500)
		sampSendChat("/unbag " .. Player_ID)
		bmenu_number = -1

	elseif bmenu_number == 10 then
		sampSendChat("/me ������� ���� ��� ��� ������, ������"..RP1.." ���")
		wait(500)
		sampSendChat("/ungag " .. Player_ID)
		bmenu_number = -1
		end
	end
end

function thread_function_kpk()
	if Player_ID == -1 and kpk_number ~= 1 and kpk_number ~= 9 and kpk_number ~= 10 and kpk_number ~= 8 then sampAddChatMessage(tag .. "������! �� �� � ��� �� ����������������.", -1)
	else
	if kpk_number == 1 then
		sampSendChat("/lmenu")
		kpk_window_state.v = false
	kpk_number = -1

	elseif kpk_number == 2 then
		sampSendChat("/invite " .. Player_ID)
		kpk_number = -1

	elseif kpk_number == 3 then
			kpk_window_state.v = not kpk_window_state.v
			kpk_input_uninvite_window_state.v = not kpk_input_uninvite_window_state.v
		kpk_number = -1

	elseif kpk_number == 4 then
		sampSendChat("/rang " .. Player_ID)
		kpk_window_state.v = false
		kpk_number = -1

	elseif kpk_number == 5 then
		sampSendChat("/setskin " .. Player_ID)
		kpk_window_state.v = false
		kpk_number = -1
	elseif kpk_number == 6 then
		sampSendChat("/black " .. Player_ID)
		kpk_number = -1
	elseif kpk_number == 7 then
		sampSendChat("/blackinfo " .. Player_ID)
		kpk_number = -1
	elseif kpk_number == 8 then
		sampSendChat("/contraband")
		kpk_window_state.v = false
		kpk_number = -1

	elseif kpk_number == 9 then
		sampSendChat("/mrespawn")
		kpk_number = -1

	elseif kpk_number == 10 then
		sampSendChat("/showall")
				kpk_window_state.v = false
		kpk_number = -1
		end
	end
end

function thread_function_mhelp_help()
	local mainIni = inicfg.load(nil, directIni)
	local positionX, positionY, positionZ = getCharCoordinates(PLAYER_PED)
	local text = mainIni.Help.help
	text = string.gsub(text, "{myid}", myID)
	text = string.gsub(text, "{mynick}", myNick)
	text = string.gsub(text, "{myrpnick}", myRPNick)
	text = string.gsub(text, "{myping}", myPing)
	text = string.gsub(text, "{myscore}", myScore)
	text = string.gsub(text, "{select_id}", Player_ID)
	text = string.gsub(text, "{select_nick}", Player_Nick)
	text = string.gsub(text, "{select_score}", Player_Score)
	text = string.gsub(text, "{select_ping}", Player_Ping)
	text = string.gsub(text, "{select_rpnick}", Player_RPNick)
	text = string.gsub(text, "{closest_id}", Closest_ID)
	text = string.gsub(text, "{closest_nick}", Closest_Nick)
	text = string.gsub(text, "{closest_score}", Closest_Score)
	text = string.gsub(text, "{closest_ping}", Closest_Ping)
	text = string.gsub(text, "{closest_rpnick}", Closest_RPNick)
	text = string.gsub(text, "{area}", calculateZone(positionX, positionY, positionZ))
	sampSendChat("/f "..u8:decode(text))
	wait(500)
	sampSendChat("/fn [Mafia Assistant]: "..positionX..", "..positionY.."")
end

function thread_function_reconnect()
	retimer = string.match(retimer, '(%d+)')
	if retimer ~= nil then
		retimer = retimer * 1000
	sampAddChatMessage(tag.."��������������� � �������..", -1)
	sampDisconnectWithReason(1)
	wait(retimer)
	sampSetGamestate(1)
	else
		sampAddChatMessage(tag.."��� �� ��������������� � �������, ������� �������: {FF2222}/rec [���]", -1)
	end
end

-- Events

function sampev.onServerMessage(color, text)
	if text:find("%[F%] %(%( .+ (.+)_(.+)%[(.+)%]: %[Mafia Assistant%]: ([-0-9.]+), ([-0-9.]+)") then
		mhelp_text = text
		mhelp()
	end
	if chatoff_bool == 1 then return false end
  if mainIni.Ignore.ignore3 and color == 16711935 and text:find("�����������:") then return false end
	if mainIni.Ignore.ignore3 and color == 866792362 and text:find("���������� ��������") then return false end
  if mainIni.Ignore.ignore2 and color == 1182971050 and text:find("%[F%] %(%(") then return false end
	if mainIni.Ignore.ignore8 and color == -11521878 and (text:find("�������������") or text:find("�������������a")) then return false end
	if mainIni.Ignore.ignore8 and color == -65366 and text:find("�����") then return false end
	if mainIni.Ignore.ignore8 and color == -6750038 and text:find("���") then return false end
	if mainIni.Ignore.ignore8 and color == -3342081 and text:find("�������������") then return false end
	if mainIni.Ignore.ignore4 and color == 1147587839 and text:find("%[���.�������%]") then return false end
	if mainIni.Ignore.ignore5 and color == -3116033 and text:find("������") then return false end
	if mainIni.Ignore.ignore5 and color == -1358102273 and text:find("������") then return false end
	if mainIni.Ignore.ignore7 and color == 869072810 then return false end
	if mainIni.Ignore.ignore7 and color == -65366 and text:find("PUBG") then return false end
	if mainIni.Ignore.ignore6 and color == -1 and text:find("�������") then return false end
	if mainIni.Ignore.ignore1 and color == 1182971050 and text:find("%[F%]") and not text:find("%[F%] %(%(") then return false end
end

function sampev.onSendChat(message)
			if message == ')' or message == '(' or message ==  '))' or message == '((' then return{message} end
			mainIni = inicfg.load(nil, directIni)
			if status_accent.v then
			return{'['..u8:decode(mainIni.Accent.accent)..']: '..message}
		else
			return{message}
		end
end

function sampev.onPlayerQuit(playerid,reason) -- 0 ����, 1 ����� /q, 2 �������
	if Player_ID == playerid then
        sampAddChatMessage(tag..'����� {FF2222}'..sampGetPlayerNickname(playerid)..' ['..playerid..'] {ffffff}����� � �������. �������: {ff2222}'..reasons[reason], -1)
				Player_ID = -1
	end
end

-- Function

function mhelp_command()
	mhelp_help()
end

function Chatoff()
	if chatoff_bool == 0 then
		chatoff_bool = 1
		sampAddChatMessage(tag.."��� ��������.", -1)
	else
		chatoff_bool = 0
		sampAddChatMessage(tag.."��� �������.", -1)
	end
end

function Unload()
	sampAddChatMessage(tag.."���������� �������..",-1)
	thisScript():unload()
end

function Reconnect(retime)
		retimer = retime
		reconnectr()
end

function Reload()
	sampAddChatMessage(tag.."������������ �������..",-1)
	thisScript():reload()
end

function RPGun()
	mainIni = inicfg.load(nil, directIni)
			if (currentWeapon == 24 or currentWeapon == 23 or currentWeapon == 22) and mainIni.Weapon.w2 == true then
				sampSendChat("/me ������ ��������, ���" ..RP1.. " ��� � ��������������")
			elseif currentWeapon == 31 and mainIni.Weapon.w5 == true then
				sampSendChat('/me ���� � ����� ������� "M4", ���' ..RP1.. ' ��� � ��������������, ����� ���� ���������' ..RP1.. ' ������')
			elseif currentWeapon == 34 and mainIni.Weapon.w8 == true then
				sampSendChat('/me ���� � ����� ����������� ��������, ���' ..RP1.. ' � � ��������������, ����� ���� ���������' ..RP1.. ' ������ ��������')
			elseif currentWeapon == 5 and mainIni.Weapon.w1 == true then
				sampSendChat('/me ���' ..RP1.. ' � ���� ����������� ����')
			elseif currentWeapon == 8 and mainIni.Weapon.w1 == true then
				sampSendChat('/me ���' ..RP1.. ' � ���� ������')
			elseif currentWeapon == 2 and mainIni.Weapon.w1 == true then
				sampSendChat('/me ���' ..RP1.. ' � ���� ������')
			elseif currentWeapon == 25 and mainIni.Weapon.w3 == true then
				sampSendChat('/me ������� ��-�� ����� ��������, ���' ..RP1.. ' ��� � ��������������')
			elseif currentWeapon == 29 and mainIni.Weapon.w4 == true then
					sampSendChat('/me ���� � ����� ��������-������� "MP5", ���' ..RP1.. ' ��� � ��������������, ����� ���� ���������' ..RP1.. ' ������')
				elseif currentWeapon == 33 and mainIni.Weapon.w7 == true then
					sampSendChat('/me ���� � ����� ��������, ���' ..RP1.. ' � � ��������������')
				elseif currentWeapon == 30 and mainIni.Weapon.w6 == true then
					sampSendChat('/me ���� � ����� ������� "AK47", ���' ..RP1.. ' ��� � ��������������, ����� ���� ���������' ..RP1.. ' ������')
			end
end

function Menu()
	if not sampIsDialogActive() and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
		main_window_state.v = not main_window_state.v
		imgui.Process = main_window_state.v
		menu_number = 1
		info_number = 1
	end
end

function Hint()
	if not sampIsChatInputActive() and not sampIsDialogActive() and not main_window_state.v and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
	hint_window_state.v = not hint_window_state.v
	imgui.Process = hint_window_state.v
	end
end

function KPK()
	if not sampIsChatInputActive() and not sampIsDialogActive() and not main_window_state.v and not bmenu_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
	kpk_window_state.v = not kpk_window_state.v
	imgui.Process = kpk_window_state.v
	end
end

function BMenu()
		if not sampIsChatInputActive() and not sampIsDialogActive() and not main_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
	bmenu_window_state.v = not bmenu_window_state.v
	imgui.Process = bmenu_window_state.v
	end
end

function Scream()
	if not sampIsChatInputActive() and not sampIsDialogActive() and not main_window_state.v and not bmenu_window_state.v and not kpk_window_state.v and not dw_window_state.v and not hint_window_state.v and hud_pos_status == 0 and not kpk_input_uninvite_window_state.v and not show_window[0] then
	if k == 1 then
	sampSendChat(u8:decode(mainIni.Scream.scream1))
	k = 2
	elseif k == 2 then
		sampSendChat(u8:decode(mainIni.Scream.scream2))
		k = 3
	elseif k == 3 then
		sampSendChat(u8:decode(mainIni.Scream.scream3))
		k = 1
	end
	end
end

function selectID(arg)
	if arg <= "999" and arg >= "0" and sampIsPlayerConnected(arg) then
		Player_ID = arg
		Player_Nick = sampGetPlayerNickname(Player_ID)
		rid1 = ""
		rid2 = ""
		rid3 = ""
		rid = ""
		sampAddChatMessage(tag .. "�� ������ �������������� � �������: {FF2222}" .. Player_Nick .. " [" .. Player_ID .. "]", -1)
	else
		Player_ID = -1
		rid1 = ""
		rid2 = ""
		rid3 = ""
		rid = ""
		sampAddChatMessage(tag .. "������ ID." , -1)
	end
end

function timer(sec)
	if tonumber(sec) and timer_status == 0 then
		timer_status = 1
			local sec = tonumber(sec)
			if sec > 0 then
					timer_thread = lua_thread.create(function()
						if status_timer.v == true then
							sampAddChatMessage(tag..'������ �� {FF2222}'..sec..'{FFFFFF} ����� �������!', -1)
							start = os.time()
							sec = sec * "60"
							else
								sampAddChatMessage(tag..'������ �� {FF2222}'..sec..'{FFFFFF} ������ �������!', -1)
							start = os.time()
							end
							while os.time() - start < sec do
									local timer_text = sec - (os.time() - start)
									printString('~r~TIMER: ' ..timer_text, 1000)
									wait(1000)
							end
							sampAddChatMessage(tag..'����� �����, ������ ����������.', -1)
							printString('~r~TIMER: 0', 1000)
							timer_status = 0
					end)
			end
			return
	end
	if timer_status == 1 then
	sampAddChatMessage(tag.."��� �� ����������� ������, ������� �������: {FF2222}/stoptimer", -1)
	else
		if status_timer.v == true then
		sampAddChatMessage(tag.. '��� �� ��������� ������, ������ �������: {FF2222}/timer [���]', -1)
		else
			sampAddChatMessage(tag.. '��� �� ��������� ������, ������ �������: {FF2222}/timer [���]', -1)
		end
	end
end

function stoptimer()
	if timer_status == 1 then
	timer_thread:terminate()
	sampAddChatMessage(tag..'������ ����������.', -1)
	timer_status = 0
	else
		if status_timer.v == true then
		sampAddChatMessage(tag.. '��� �� ��������� ������, ������ �������: {FF2222}/timer [���]', -1)
		else
			sampAddChatMessage(tag.. '��� �� ��������� ������, ������ �������: {FF2222}/timer [���]', -1)
		end
	end
end

function cancelID()
	Player_ID = -1
	rid1 = ""
	rid2 = ""
	rid3 = ""
	rid = ""
end

function ClearChat()
    local memory = require "memory"
    memory.fill(sampGetChatInfoPtr() + 306, 0x0, 25200)
    memory.write(sampGetChatInfoPtr() + 306, 25562, 4, 0x0)
    memory.write(sampGetChatInfoPtr() + 0x63DA, 1, 1)
end

function takeScreen()
  if isSampLoaded() then
    require("ffi").cast("void (*__stdcall)()", sampGetBase() + 0x70FC0)()
  end
end

-- Technical Function

function imgui.CenterColumnText(text)
    imgui.SetCursorPosX((imgui.GetColumnOffset() + (imgui.GetColumnWidth() / 2)) - imgui.CalcTextSize(text).x / 2)
    imgui.Text(text)
end

function imgui.VerticalSeparator()
    local p = imgui.GetCursorScreenPos()
    imgui.GetWindowDrawList():AddLine(imgui.ImVec2(p.x, p.y), imgui.ImVec2(p.x, p.y + 999999999999999999), imgui.GetColorU32(imgui.GetStyle().Colors[imgui.Col.Separator]))
end

function setMarker(type,x,y,z)
    bs = raknetNewBitStream()
    raknetBitStreamWriteInt8(bs, type)
    raknetBitStreamWriteFloat(bs, x)
    raknetBitStreamWriteFloat(bs, y)
    raknetBitStreamWriteFloat(bs, z)
    raknetBitStreamWriteFloat(bs, 0)
    raknetBitStreamWriteFloat(bs, 0)
    raknetBitStreamWriteFloat(bs, 0)
    raknetBitStreamWriteFloat(bs, 6)
    raknetEmulRpcReceiveBitStream(38, bs)
    raknetDeleteBitStream(bs)
end

function imgui.ButtonDisabled(...)

    local r, g, b, a = imgui.ImColor(imgui.GetStyle().Colors[imgui.Col.Button]):GetFloat4()

    imgui.PushStyleColor(imgui.Col.Button, imgui.ImVec4(r, g, b, a/2) )
    imgui.PushStyleColor(imgui.Col.ButtonHovered, imgui.ImVec4(r, g, b, a/2))
    imgui.PushStyleColor(imgui.Col.ButtonActive, imgui.ImVec4(r, g, b, a/2))
    imgui.PushStyleColor(imgui.Col.Text, imgui.GetStyle().Colors[imgui.Col.TextDisabled])

        local result = imgui.Button(...)

    imgui.PopStyleColor()
    imgui.PopStyleColor()
    imgui.PopStyleColor()
    imgui.PopStyleColor()

    return result
end

function getClosestPlayerId()
    local minDist = 9999
    local closestId = -1
    local x, y, z = getCharCoordinates(PLAYER_PED)
    for i = 0, 999 do
        local streamed, pedID = sampGetCharHandleBySampPlayerId(i)
        if streamed then
            local xi, yi, zi = getCharCoordinates(pedID)
            local dist = math.sqrt( (xi - x) ^ 2 + (yi - y) ^ 2 + (zi - z) ^ 2 )
            if dist < minDist then
                minDist = dist
                closestId = i
            end
        end
    end
    return closestId
end

function ShowHelpMarker(text)
	imgui.SameLine()
    imgui.TextDisabled(fa.ICON_QUESTION_CIRCLE_O)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(u8(text))
    end
end

function updateHint()
	mainIni = inicfg.load(nil, directIni)
	if combo_hint_select.v ~= combo_hint_select_update then
		mainIni = inicfg.load(nil, directIni)
	if combo_hint_select.v == 0 then
		hintid = "1"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint1)
	elseif combo_hint_select.v == 1 then
		hintid = "2"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint2)
	elseif combo_hint_select.v == 2 then
		hintid = "3"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint3)
	elseif combo_hint_select.v == 3 then
		hintid = "4"
		combo_hint_select_update = combo_hint_select.v
	hint_header_text.v = tostring(mainIni.Hint.hint4)
	elseif combo_hint_select.v == 4 then
		hintid = "5"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint5)
	elseif combo_hint_select.v == 5 then
		hintid = "6"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint6)
	elseif combo_hint_select.v == 6 then
		hintid = "7"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint7)
	elseif combo_hint_select.v == 7 then
		hintid = "8"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint8)
	elseif combo_hint_select.v == 8 then
		hintid = "9"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint9)
	elseif combo_hint_select.v == 9 then
		hintid = "10"
		combo_hint_select_update = combo_hint_select.v
		hint_header_text.v = tostring(mainIni.Hint.hint10)
	end
		file = io.open(getGameDirectory().."//moonloader//Mafia Assistant//Hint//hint"..hintid..".txt", "r")
		hint_text.v= file:read('*a')
		file:close()
		end
end

function imgui.CheckComboBox(str_id, array, chosen_array)
    local p = imgui.GetCursorScreenPos()
    local pos = imgui.GetWindowPos()
    local choose = imgui.ImInt(0)
    local textbuffer = table.concat(chosen_array, ", ", 1,#chosen_array)
    local buf = imgui.ImBuffer(textbuffer,256)
    for i = 1, #chosen_array do
        if chosen_array[i]:find('[+]') then
            chosen_array[i] = chosen_array[i]:match("%p+%p(.+)")
        end
    end
    if imgui.Combo(str_id, choose, array) then
        for i = 0, #array do
            if choose.v == i then
                chosen.v = false
                for k,v in ipairs(chosen_array) do
                    if '[+]' .. v == array[i+1] then
                        chosen.v = true
                        table.remove(chosen_array,k)
                        array[i+1] = array[i+1]:match("%p+%p(.+)")
                    end
                end
                if not chosen.v then
                    table.insert(chosen_array, array[i+1])
                    table.remove(array, i+1)
                    table.insert(array,i+1,'[+]' .. chosen_array[#chosen_array])
                end
            end
        end
    end
    imgui.SameLine()
    imgui.SetCursorPosX(p.x-pos.x)
    imgui.PushItemWidth(imgui.CalcItemWidth()-20)
    imgui.InputText("##" .. str_id,buf)
    imgui.NewLine()
end

function imgui.TextCenter(text)
    local textSize = imgui.CalcTextSize(text)
    imgui.SetCursorPosX(imgui.GetWindowWidth() / 2 - textSize.x / 2)
    return imgui.Text(text)
end

function calculateZone(x, y, z)
    local streets = {{"Avispa Country Club", -2667.810, -302.135, -28.831, -2646.400, -262.320, 71.169},
    {"Easter Bay Airport", -1315.420, -405.388, 15.406, -1264.400, -209.543, 25.406},
    {"Avispa Country Club", -2550.040, -355.493, 0.000, -2470.040, -318.493, 39.700},
    {"Easter Bay Airport", -1490.330, -209.543, 15.406, -1264.400, -148.388, 25.406},
    {"Garcia", -2395.140, -222.589, -5.3, -2354.090, -204.792, 200.000},
    {"Shady Cabin", -1632.830, -2263.440, -3.0, -1601.330, -2231.790, 200.000},
    {"East Los Santos", 2381.680, -1494.030, -89.084, 2421.030, -1454.350, 110.916},
    {"LVA Freight Depot", 1236.630, 1163.410, -89.084, 1277.050, 1203.280, 110.916},
    {"Blackfield Intersection", 1277.050, 1044.690, -89.084, 1315.350, 1087.630, 110.916},
    {"Avispa Country Club", -2470.040, -355.493, 0.000, -2270.040, -318.493, 46.100},
    {"Temple", 1252.330, -926.999, -89.084, 1357.000, -910.170, 110.916},
    {"Unity Station", 1692.620, -1971.800, -20.492, 1812.620, -1932.800, 79.508},
    {"LVA Freight Depot", 1315.350, 1044.690, -89.084, 1375.600, 1087.630, 110.916},
    {"Los Flores", 2581.730, -1454.350, -89.084, 2632.830, -1393.420, 110.916},
    {"Starfish Casino", 2437.390, 1858.100, -39.084, 2495.090, 1970.850, 60.916},
    {"Easter Bay Chemicals", -1132.820, -787.391, 0.000, -956.476, -768.027, 200.000},
    {"Downtown Los Santos", 1370.850, -1170.870, -89.084, 1463.900, -1130.850, 110.916},
    {"Esplanade East", -1620.300, 1176.520, -4.5, -1580.010, 1274.260, 200.000},
    {"Market Station", 787.461, -1410.930, -34.126, 866.009, -1310.210, 65.874},
    {"Linden Station", 2811.250, 1229.590, -39.594, 2861.250, 1407.590, 60.406},
    {"Montgomery Intersection", 1582.440, 347.457, 0.000, 1664.620, 401.750, 200.000},
    {"Frederick Bridge", 2759.250, 296.501, 0.000, 2774.250, 594.757, 200.000},
    {"Yellow Bell Station", 1377.480, 2600.430, -21.926, 1492.450, 2687.360, 78.074},
    {"Downtown Los Santos", 1507.510, -1385.210, 110.916, 1582.550, -1325.310, 335.916},
    {"Jefferson", 2185.330, -1210.740, -89.084, 2281.450, -1154.590, 110.916},
    {"Mulholland", 1318.130, -910.170, -89.084, 1357.000, -768.027, 110.916},
    {"Avispa Country Club", -2361.510, -417.199, 0.000, -2270.040, -355.493, 200.000},
    {"Jefferson", 1996.910, -1449.670, -89.084, 2056.860, -1350.720, 110.916},
    {"Julius Thruway West", 1236.630, 2142.860, -89.084, 1297.470, 2243.230, 110.916},
    {"Jefferson", 2124.660, -1494.030, -89.084, 2266.210, -1449.670, 110.916},
    {"Julius Thruway North", 1848.400, 2478.490, -89.084, 1938.800, 2553.490, 110.916},
    {"Rodeo", 422.680, -1570.200, -89.084, 466.223, -1406.050, 110.916},
    {"Cranberry Station", -2007.830, 56.306, 0.000, -1922.000, 224.782, 100.000},
    {"Downtown Los Santos", 1391.050, -1026.330, -89.084, 1463.900, -926.999, 110.916},
    {"Redsands West", 1704.590, 2243.230, -89.084, 1777.390, 2342.830, 110.916},
    {"Little Mexico", 1758.900, -1722.260, -89.084, 1812.620, -1577.590, 110.916},
    {"Blackfield Intersection", 1375.600, 823.228, -89.084, 1457.390, 919.447, 110.916},
    {"Los Santos International", 1974.630, -2394.330, -39.084, 2089.000, -2256.590, 60.916},
    {"Beacon Hill", -399.633, -1075.520, -1.489, -319.033, -977.516, 198.511},
    {"Rodeo", 334.503, -1501.950, -89.084, 422.680, -1406.050, 110.916},
    {"Richman", 225.165, -1369.620, -89.084, 334.503, -1292.070, 110.916},
    {"Downtown Los Santos", 1724.760, -1250.900, -89.084, 1812.620, -1150.870, 110.916},
    {"The Strip", 2027.400, 1703.230, -89.084, 2137.400, 1783.230, 110.916},
    {"Downtown Los Santos", 1378.330, -1130.850, -89.084, 1463.900, -1026.330, 110.916},
    {"Blackfield Intersection", 1197.390, 1044.690, -89.084, 1277.050, 1163.390, 110.916},
    {"Conference Center", 1073.220, -1842.270, -89.084, 1323.900, -1804.210, 110.916},
    {"Montgomery", 1451.400, 347.457, -6.1, 1582.440, 420.802, 200.000},
    {"Foster Valley", -2270.040, -430.276, -1.2, -2178.690, -324.114, 200.000},
    {"Blackfield Chapel", 1325.600, 596.349, -89.084, 1375.600, 795.010, 110.916},
    {"Los Santos International", 2051.630, -2597.260, -39.084, 2152.450, -2394.330, 60.916},
    {"Mulholland", 1096.470, -910.170, -89.084, 1169.130, -768.027, 110.916},
    {"Yellow Bell Gol Course", 1457.460, 2723.230, -89.084, 1534.560, 2863.230, 110.916},
    {"The Strip", 2027.400, 1783.230, -89.084, 2162.390, 1863.230, 110.916},
    {"Jefferson", 2056.860, -1210.740, -89.084, 2185.330, -1126.320, 110.916},
    {"Mulholland", 952.604, -937.184, -89.084, 1096.470, -860.619, 110.916},
    {"Aldea Malvada", -1372.140, 2498.520, 0.000, -1277.590, 2615.350, 200.000},
    {"Las Colinas", 2126.860, -1126.320, -89.084, 2185.330, -934.489, 110.916},
    {"Las Colinas", 1994.330, -1100.820, -89.084, 2056.860, -920.815, 110.916},
    {"Richman", 647.557, -954.662, -89.084, 768.694, -860.619, 110.916},
    {"LVA Freight Depot", 1277.050, 1087.630, -89.084, 1375.600, 1203.280, 110.916},
    {"Julius Thruway North", 1377.390, 2433.230, -89.084, 1534.560, 2507.230, 110.916},
    {"Willowfield", 2201.820, -2095.000, -89.084, 2324.000, -1989.900, 110.916},
    {"Julius Thruway North", 1704.590, 2342.830, -89.084, 1848.400, 2433.230, 110.916},
    {"Temple", 1252.330, -1130.850, -89.084, 1378.330, -1026.330, 110.916},
    {"Little Mexico", 1701.900, -1842.270, -89.084, 1812.620, -1722.260, 110.916},
    {"Queens", -2411.220, 373.539, 0.000, -2253.540, 458.411, 200.000},
    {"Las Venturas Airport", 1515.810, 1586.400, -12.500, 1729.950, 1714.560, 87.500},
    {"Richman", 225.165, -1292.070, -89.084, 466.223, -1235.070, 110.916},
    {"Temple", 1252.330, -1026.330, -89.084, 1391.050, -926.999, 110.916},
    {"East Los Santos", 2266.260, -1494.030, -89.084, 2381.680, -1372.040, 110.916},
    {"Julius Thruway East", 2623.180, 943.235, -89.084, 2749.900, 1055.960, 110.916},
    {"Willowfield", 2541.700, -1941.400, -89.084, 2703.580, -1852.870, 110.916},
    {"Las Colinas", 2056.860, -1126.320, -89.084, 2126.860, -920.815, 110.916},
    {"Julius Thruway East", 2625.160, 2202.760, -89.084, 2685.160, 2442.550, 110.916},
    {"Rodeo", 225.165, -1501.950, -89.084, 334.503, -1369.620, 110.916},
    {"Las Brujas", -365.167, 2123.010, -3.0, -208.570, 2217.680, 200.000},
    {"Julius Thruway East", 2536.430, 2442.550, -89.084, 2685.160, 2542.550, 110.916},
    {"Rodeo", 334.503, -1406.050, -89.084, 466.223, -1292.070, 110.916},
    {"Vinewood", 647.557, -1227.280, -89.084, 787.461, -1118.280, 110.916},
    {"Rodeo", 422.680, -1684.650, -89.084, 558.099, -1570.200, 110.916},
    {"Julius Thruway North", 2498.210, 2542.550, -89.084, 2685.160, 2626.550, 110.916},
    {"Downtown Los Santos", 1724.760, -1430.870, -89.084, 1812.620, -1250.900, 110.916},
    {"Rodeo", 225.165, -1684.650, -89.084, 312.803, -1501.950, 110.916},
    {"Jefferson", 2056.860, -1449.670, -89.084, 2266.210, -1372.040, 110.916},
    {"Hampton Barns", 603.035, 264.312, 0.000, 761.994, 366.572, 200.000},
    {"Temple", 1096.470, -1130.840, -89.084, 1252.330, -1026.330, 110.916},
    {"Kincaid Bridge", -1087.930, 855.370, -89.084, -961.950, 986.281, 110.916},
    {"Verona Beach", 1046.150, -1722.260, -89.084, 1161.520, -1577.590, 110.916},
    {"Commerce", 1323.900, -1722.260, -89.084, 1440.900, -1577.590, 110.916},
    {"Mulholland", 1357.000, -926.999, -89.084, 1463.900, -768.027, 110.916},
    {"Rodeo", 466.223, -1570.200, -89.084, 558.099, -1385.070, 110.916},
    {"Mulholland", 911.802, -860.619, -89.084, 1096.470, -768.027, 110.916},
    {"Mulholland", 768.694, -954.662, -89.084, 952.604, -860.619, 110.916},
    {"Julius Thruway South", 2377.390, 788.894, -89.084, 2537.390, 897.901, 110.916},
    {"Idlewood", 1812.620, -1852.870, -89.084, 1971.660, -1742.310, 110.916},
    {"Ocean Docks", 2089.000, -2394.330, -89.084, 2201.820, -2235.840, 110.916},
    {"Commerce", 1370.850, -1577.590, -89.084, 1463.900, -1384.950, 110.916},
    {"Julius Thruway North", 2121.400, 2508.230, -89.084, 2237.400, 2663.170, 110.916},
    {"Temple", 1096.470, -1026.330, -89.084, 1252.330, -910.170, 110.916},
    {"Glen Park", 1812.620, -1449.670, -89.084, 1996.910, -1350.720, 110.916},
    {"Easter Bay Airport", -1242.980, -50.096, 0.000, -1213.910, 578.396, 200.000},
    {"Martin Bridge", -222.179, 293.324, 0.000, -122.126, 476.465, 200.000},
    {"The Strip", 2106.700, 1863.230, -89.084, 2162.390, 2202.760, 110.916},
    {"Willowfield", 2541.700, -2059.230, -89.084, 2703.580, -1941.400, 110.916},
    {"Marina", 807.922, -1577.590, -89.084, 926.922, -1416.250, 110.916},
    {"Las Venturas Airport", 1457.370, 1143.210, -89.084, 1777.400, 1203.280, 110.916},
    {"Idlewood", 1812.620, -1742.310, -89.084, 1951.660, -1602.310, 110.916},
    {"Esplanade East", -1580.010, 1025.980, -6.1, -1499.890, 1274.260, 200.000},
    {"Downtown Los Santos", 1370.850, -1384.950, -89.084, 1463.900, -1170.870, 110.916},
    {"The Mako Span", 1664.620, 401.750, 0.000, 1785.140, 567.203, 200.000},
    {"Rodeo", 312.803, -1684.650, -89.084, 422.680, -1501.950, 110.916},
    {"Pershing Square", 1440.900, -1722.260, -89.084, 1583.500, -1577.590, 110.916},
    {"Mulholland", 687.802, -860.619, -89.084, 911.802, -768.027, 110.916},
    {"Gant Bridge", -2741.070, 1490.470, -6.1, -2616.400, 1659.680, 200.000},
    {"Las Colinas", 2185.330, -1154.590, -89.084, 2281.450, -934.489, 110.916},
    {"Mulholland", 1169.130, -910.170, -89.084, 1318.130, -768.027, 110.916},
    {"Julius Thruway North", 1938.800, 2508.230, -89.084, 2121.400, 2624.230, 110.916},
    {"Commerce", 1667.960, -1577.590, -89.084, 1812.620, -1430.870, 110.916},
    {"Rodeo", 72.648, -1544.170, -89.084, 225.165, -1404.970, 110.916},
    {"Roca Escalante", 2536.430, 2202.760, -89.084, 2625.160, 2442.550, 110.916},
    {"Rodeo", 72.648, -1684.650, -89.084, 225.165, -1544.170, 110.916},
    {"Market", 952.663, -1310.210, -89.084, 1072.660, -1130.850, 110.916},
    {"Las Colinas", 2632.740, -1135.040, -89.084, 2747.740, -945.035, 110.916},
    {"Mulholland", 861.085, -674.885, -89.084, 1156.550, -600.896, 110.916},
    {"King's", -2253.540, 373.539, -9.1, -1993.280, 458.411, 200.000},
    {"Redsands East", 1848.400, 2342.830, -89.084, 2011.940, 2478.490, 110.916},
    {"Downtown", -1580.010, 744.267, -6.1, -1499.890, 1025.980, 200.000},
    {"Conference Center", 1046.150, -1804.210, -89.084, 1323.900, -1722.260, 110.916},
    {"Richman", 647.557, -1118.280, -89.084, 787.461, -954.662, 110.916},
    {"Ocean Flats", -2994.490, 277.411, -9.1, -2867.850, 458.411, 200.000},
    {"Greenglass College", 964.391, 930.890, -89.084, 1166.530, 1044.690, 110.916},
    {"Glen Park", 1812.620, -1100.820, -89.084, 1994.330, -973.380, 110.916},
    {"LVA Freight Depot", 1375.600, 919.447, -89.084, 1457.370, 1203.280, 110.916},
    {"Regular Tom", -405.770, 1712.860, -3.0, -276.719, 1892.750, 200.000},
    {"Verona Beach", 1161.520, -1722.260, -89.084, 1323.900, -1577.590, 110.916},
    {"East Los Santos", 2281.450, -1372.040, -89.084, 2381.680, -1135.040, 110.916},
    {"Caligula's Palace", 2137.400, 1703.230, -89.084, 2437.390, 1783.230, 110.916},
    {"Idlewood", 1951.660, -1742.310, -89.084, 2124.660, -1602.310, 110.916},
    {"Pilgrim", 2624.400, 1383.230, -89.084, 2685.160, 1783.230, 110.916},
    {"Idlewood", 2124.660, -1742.310, -89.084, 2222.560, -1494.030, 110.916},
    {"Queens", -2533.040, 458.411, 0.000, -2329.310, 578.396, 200.000},
    {"Downtown", -1871.720, 1176.420, -4.5, -1620.300, 1274.260, 200.000},
    {"Commerce", 1583.500, -1722.260, -89.084, 1758.900, -1577.590, 110.916},
    {"East Los Santos", 2381.680, -1454.350, -89.084, 2462.130, -1135.040, 110.916},
    {"Marina", 647.712, -1577.590, -89.084, 807.922, -1416.250, 110.916},
    {"Richman", 72.648, -1404.970, -89.084, 225.165, -1235.070, 110.916},
    {"Vinewood", 647.712, -1416.250, -89.084, 787.461, -1227.280, 110.916},
    {"East Los Santos", 2222.560, -1628.530, -89.084, 2421.030, -1494.030, 110.916},
    {"Rodeo", 558.099, -1684.650, -89.084, 647.522, -1384.930, 110.916},
    {"Easter Tunnel", -1709.710, -833.034, -1.5, -1446.010, -730.118, 200.000},
    {"Rodeo", 466.223, -1385.070, -89.084, 647.522, -1235.070, 110.916},
    {"Redsands East", 1817.390, 2202.760, -89.084, 2011.940, 2342.830, 110.916},
    {"The Clown's Pocket", 2162.390, 1783.230, -89.084, 2437.390, 1883.230, 110.916},
    {"Idlewood", 1971.660, -1852.870, -89.084, 2222.560, -1742.310, 110.916},
    {"Montgomery Intersection", 1546.650, 208.164, 0.000, 1745.830, 347.457, 200.000},
    {"Willowfield", 2089.000, -2235.840, -89.084, 2201.820, -1989.900, 110.916},
    {"Temple", 952.663, -1130.840, -89.084, 1096.470, -937.184, 110.916},
    {"Prickle Pine", 1848.400, 2553.490, -89.084, 1938.800, 2863.230, 110.916},
    {"Los Santos International", 1400.970, -2669.260, -39.084, 2189.820, -2597.260, 60.916},
    {"Garver Bridge", -1213.910, 950.022, -89.084, -1087.930, 1178.930, 110.916},
    {"Garver Bridge", -1339.890, 828.129, -89.084, -1213.910, 1057.040, 110.916},
    {"Kincaid Bridge", -1339.890, 599.218, -89.084, -1213.910, 828.129, 110.916},
    {"Kincaid Bridge", -1213.910, 721.111, -89.084, -1087.930, 950.022, 110.916},
    {"Verona Beach", 930.221, -2006.780, -89.084, 1073.220, -1804.210, 110.916},
    {"Verdant Bluffs", 1073.220, -2006.780, -89.084, 1249.620, -1842.270, 110.916},
    {"Vinewood", 787.461, -1130.840, -89.084, 952.604, -954.662, 110.916},
    {"Vinewood", 787.461, -1310.210, -89.084, 952.663, -1130.840, 110.916},
    {"Commerce", 1463.900, -1577.590, -89.084, 1667.960, -1430.870, 110.916},
    {"Market", 787.461, -1416.250, -89.084, 1072.660, -1310.210, 110.916},
    {"Rockshore West", 2377.390, 596.349, -89.084, 2537.390, 788.894, 110.916},
    {"Julius Thruway North", 2237.400, 2542.550, -89.084, 2498.210, 2663.170, 110.916},
    {"East Beach", 2632.830, -1668.130, -89.084, 2747.740, -1393.420, 110.916},
    {"Fallow Bridge", 434.341, 366.572, 0.000, 603.035, 555.680, 200.000},
    {"Willowfield", 2089.000, -1989.900, -89.084, 2324.000, -1852.870, 110.916},
    {"Chinatown", -2274.170, 578.396, -7.6, -2078.670, 744.170, 200.000},
    {"El Castillo del Diablo", -208.570, 2337.180, 0.000, 8.430, 2487.180, 200.000},
    {"Ocean Docks", 2324.000, -2145.100, -89.084, 2703.580, -2059.230, 110.916},
    {"Easter Bay Chemicals", -1132.820, -768.027, 0.000, -956.476, -578.118, 200.000},
    {"The Visage", 1817.390, 1703.230, -89.084, 2027.400, 1863.230, 110.916},
    {"Ocean Flats", -2994.490, -430.276, -1.2, -2831.890, -222.589, 200.000},
    {"Richman", 321.356, -860.619, -89.084, 687.802, -768.027, 110.916},
    {"Green Palms", 176.581, 1305.450, -3.0, 338.658, 1520.720, 200.000},
    {"Richman", 321.356, -768.027, -89.084, 700.794, -674.885, 110.916},
    {"Starfish Casino", 2162.390, 1883.230, -89.084, 2437.390, 2012.180, 110.916},
    {"East Beach", 2747.740, -1668.130, -89.084, 2959.350, -1498.620, 110.916},
    {"Jefferson", 2056.860, -1372.040, -89.084, 2281.450, -1210.740, 110.916},
    {"Downtown Los Santos", 1463.900, -1290.870, -89.084, 1724.760, -1150.870, 110.916},
    {"Downtown Los Santos", 1463.900, -1430.870, -89.084, 1724.760, -1290.870, 110.916},
    {"Garver Bridge", -1499.890, 696.442, -179.615, -1339.890, 925.353, 20.385},
    {"Julius Thruway South", 1457.390, 823.228, -89.084, 2377.390, 863.229, 110.916},
    {"East Los Santos", 2421.030, -1628.530, -89.084, 2632.830, -1454.350, 110.916},
    {"Greenglass College", 964.391, 1044.690, -89.084, 1197.390, 1203.220, 110.916},
    {"Las Colinas", 2747.740, -1120.040, -89.084, 2959.350, -945.035, 110.916},
    {"Mulholland", 737.573, -768.027, -89.084, 1142.290, -674.885, 110.916},
    {"Ocean Docks", 2201.820, -2730.880, -89.084, 2324.000, -2418.330, 110.916},
    {"East Los Santos", 2462.130, -1454.350, -89.084, 2581.730, -1135.040, 110.916},
    {"Ganton", 2222.560, -1722.330, -89.084, 2632.830, -1628.530, 110.916},
    {"Avispa Country Club", -2831.890, -430.276, -6.1, -2646.400, -222.589, 200.000},
    {"Willowfield", 1970.620, -2179.250, -89.084, 2089.000, -1852.870, 110.916},
    {"Esplanade North", -1982.320, 1274.260, -4.5, -1524.240, 1358.900, 200.000},
    {"The High Roller", 1817.390, 1283.230, -89.084, 2027.390, 1469.230, 110.916},
    {"Ocean Docks", 2201.820, -2418.330, -89.084, 2324.000, -2095.000, 110.916},
    {"Last Dime Motel", 1823.080, 596.349, -89.084, 1997.220, 823.228, 110.916},
    {"Bayside Marina", -2353.170, 2275.790, 0.000, -2153.170, 2475.790, 200.000},
    {"King's", -2329.310, 458.411, -7.6, -1993.280, 578.396, 200.000},
    {"El Corona", 1692.620, -2179.250, -89.084, 1812.620, -1842.270, 110.916},
    {"Blackfield Chapel", 1375.600, 596.349, -89.084, 1558.090, 823.228, 110.916},
    {"The Pink Swan", 1817.390, 1083.230, -89.084, 2027.390, 1283.230, 110.916},
    {"Julius Thruway West", 1197.390, 1163.390, -89.084, 1236.630, 2243.230, 110.916},
    {"Los Flores", 2581.730, -1393.420, -89.084, 2747.740, -1135.040, 110.916},
    {"The Visage", 1817.390, 1863.230, -89.084, 2106.700, 2011.830, 110.916},
    {"Prickle Pine", 1938.800, 2624.230, -89.084, 2121.400, 2861.550, 110.916},
    {"Verona Beach", 851.449, -1804.210, -89.084, 1046.150, -1577.590, 110.916},
    {"Robada Intersection", -1119.010, 1178.930, -89.084, -862.025, 1351.450, 110.916},
    {"Linden Side", 2749.900, 943.235, -89.084, 2923.390, 1198.990, 110.916},
    {"Ocean Docks", 2703.580, -2302.330, -89.084, 2959.350, -2126.900, 110.916},
    {"Willowfield", 2324.000, -2059.230, -89.084, 2541.700, -1852.870, 110.916},
    {"King's", -2411.220, 265.243, -9.1, -1993.280, 373.539, 200.000},
    {"Commerce", 1323.900, -1842.270, -89.084, 1701.900, -1722.260, 110.916},
    {"Mulholland", 1269.130, -768.027, -89.084, 1414.070, -452.425, 110.916},
    {"Marina", 647.712, -1804.210, -89.084, 851.449, -1577.590, 110.916},
    {"Battery Point", -2741.070, 1268.410, -4.5, -2533.040, 1490.470, 200.000},
    {"The Four Dragons Casino", 1817.390, 863.232, -89.084, 2027.390, 1083.230, 110.916},
    {"Blackfield", 964.391, 1203.220, -89.084, 1197.390, 1403.220, 110.916},
    {"Julius Thruway North", 1534.560, 2433.230, -89.084, 1848.400, 2583.230, 110.916},
    {"Yellow Bell Gol Course", 1117.400, 2723.230, -89.084, 1457.460, 2863.230, 110.916},
    {"Idlewood", 1812.620, -1602.310, -89.084, 2124.660, -1449.670, 110.916},
    {"Redsands West", 1297.470, 2142.860, -89.084, 1777.390, 2243.230, 110.916},
    {"Doherty", -2270.040, -324.114, -1.2, -1794.920, -222.589, 200.000},
    {"Hilltop Farm", 967.383, -450.390, -3.0, 1176.780, -217.900, 200.000},
    {"Las Barrancas", -926.130, 1398.730, -3.0, -719.234, 1634.690, 200.000},
    {"Pirates in Men's Pants", 1817.390, 1469.230, -89.084, 2027.400, 1703.230, 110.916},
    {"City Hall", -2867.850, 277.411, -9.1, -2593.440, 458.411, 200.000},
    {"Avispa Country Club", -2646.400, -355.493, 0.000, -2270.040, -222.589, 200.000},
    {"The Strip", 2027.400, 863.229, -89.084, 2087.390, 1703.230, 110.916},
    {"Hashbury", -2593.440, -222.589, -1.0, -2411.220, 54.722, 200.000},
    {"Los Santos International", 1852.000, -2394.330, -89.084, 2089.000, -2179.250, 110.916},
    {"Whitewood Estates", 1098.310, 1726.220, -89.084, 1197.390, 2243.230, 110.916},
    {"Sherman Reservoir", -789.737, 1659.680, -89.084, -599.505, 1929.410, 110.916},
    {"El Corona", 1812.620, -2179.250, -89.084, 1970.620, -1852.870, 110.916},
    {"Downtown", -1700.010, 744.267, -6.1, -1580.010, 1176.520, 200.000},
    {"Foster Valley", -2178.690, -1250.970, 0.000, -1794.920, -1115.580, 200.000},
    {"Las Payasadas", -354.332, 2580.360, 2.0, -133.625, 2816.820, 200.000},
    {"Valle Ocultado", -936.668, 2611.440, 2.0, -715.961, 2847.900, 200.000},
    {"Blackfield Intersection", 1166.530, 795.010, -89.084, 1375.600, 1044.690, 110.916},
    {"Ganton", 2222.560, -1852.870, -89.084, 2632.830, -1722.330, 110.916},
    {"Easter Bay Airport", -1213.910, -730.118, 0.000, -1132.820, -50.096, 200.000},
    {"Redsands East", 1817.390, 2011.830, -89.084, 2106.700, 2202.760, 110.916},
    {"Esplanade East", -1499.890, 578.396, -79.615, -1339.890, 1274.260, 20.385},
    {"Caligula's Palace", 2087.390, 1543.230, -89.084, 2437.390, 1703.230, 110.916},
    {"Royal Casino", 2087.390, 1383.230, -89.084, 2437.390, 1543.230, 110.916},
    {"Richman", 72.648, -1235.070, -89.084, 321.356, -1008.150, 110.916},
    {"Starfish Casino", 2437.390, 1783.230, -89.084, 2685.160, 2012.180, 110.916},
    {"Mulholland", 1281.130, -452.425, -89.084, 1641.130, -290.913, 110.916},
    {"Downtown", -1982.320, 744.170, -6.1, -1871.720, 1274.260, 200.000},
    {"Hankypanky Point", 2576.920, 62.158, 0.000, 2759.250, 385.503, 200.000},
    {"K.A.C.C. Military Fuels", 2498.210, 2626.550, -89.084, 2749.900, 2861.550, 110.916},
    {"Harry Gold Parkway", 1777.390, 863.232, -89.084, 1817.390, 2342.830, 110.916},
    {"Bayside Tunnel", -2290.190, 2548.290, -89.084, -1950.190, 2723.290, 110.916},
    {"Ocean Docks", 2324.000, -2302.330, -89.084, 2703.580, -2145.100, 110.916},
    {"Richman", 321.356, -1044.070, -89.084, 647.557, -860.619, 110.916},
    {"Randolph Industrial Estate", 1558.090, 596.349, -89.084, 1823.080, 823.235, 110.916},
    {"East Beach", 2632.830, -1852.870, -89.084, 2959.350, -1668.130, 110.916},
    {"Flint Water", -314.426, -753.874, -89.084, -106.339, -463.073, 110.916},
    {"Blueberry", 19.607, -404.136, 3.8, 349.607, -220.137, 200.000},
    {"Linden Station", 2749.900, 1198.990, -89.084, 2923.390, 1548.990, 110.916},
    {"Glen Park", 1812.620, -1350.720, -89.084, 2056.860, -1100.820, 110.916},
    {"Downtown", -1993.280, 265.243, -9.1, -1794.920, 578.396, 200.000},
    {"Redsands West", 1377.390, 2243.230, -89.084, 1704.590, 2433.230, 110.916},
    {"Richman", 321.356, -1235.070, -89.084, 647.522, -1044.070, 110.916},
    {"Gant Bridge", -2741.450, 1659.680, -6.1, -2616.400, 2175.150, 200.000},
    {"Lil' Probe Inn", -90.218, 1286.850, -3.0, 153.859, 1554.120, 200.000},
    {"Flint Intersection", -187.700, -1596.760, -89.084, 17.063, -1276.600, 110.916},
    {"Las Colinas", 2281.450, -1135.040, -89.084, 2632.740, -945.035, 110.916},
    {"Sobell Rail Yards", 2749.900, 1548.990, -89.084, 2923.390, 1937.250, 110.916},
    {"The Emerald Isle", 2011.940, 2202.760, -89.084, 2237.400, 2508.230, 110.916},
    {"El Castillo del Diablo", -208.570, 2123.010, -7.6, 114.033, 2337.180, 200.000},
    {"Santa Flora", -2741.070, 458.411, -7.6, -2533.040, 793.411, 200.000},
    {"Playa del Seville", 2703.580, -2126.900, -89.084, 2959.350, -1852.870, 110.916},
    {"Market", 926.922, -1577.590, -89.084, 1370.850, -1416.250, 110.916},
    {"Queens", -2593.440, 54.722, 0.000, -2411.220, 458.411, 200.000},
    {"Pilson Intersection", 1098.390, 2243.230, -89.084, 1377.390, 2507.230, 110.916},
    {"Spinybed", 2121.400, 2663.170, -89.084, 2498.210, 2861.550, 110.916},
    {"Pilgrim", 2437.390, 1383.230, -89.084, 2624.400, 1783.230, 110.916},
    {"Blackfield", 964.391, 1403.220, -89.084, 1197.390, 1726.220, 110.916},
    {"'The Big Ear'", -410.020, 1403.340, -3.0, -137.969, 1681.230, 200.000},
    {"Dillimore", 580.794, -674.885, -9.5, 861.085, -404.790, 200.000},
    {"El Quebrados", -1645.230, 2498.520, 0.000, -1372.140, 2777.850, 200.000},
    {"Esplanade North", -2533.040, 1358.900, -4.5, -1996.660, 1501.210, 200.000},
    {"Easter Bay Airport", -1499.890, -50.096, -1.0, -1242.980, 249.904, 200.000},
    {"Fisher's Lagoon", 1916.990, -233.323, -100.000, 2131.720, 13.800, 200.000},
    {"Mulholland", 1414.070, -768.027, -89.084, 1667.610, -452.425, 110.916},
    {"East Beach", 2747.740, -1498.620, -89.084, 2959.350, -1120.040, 110.916},
    {"San Andreas Sound", 2450.390, 385.503, -100.000, 2759.250, 562.349, 200.000},
    {"Shady Creeks", -2030.120, -2174.890, -6.1, -1820.640, -1771.660, 200.000},
    {"Market", 1072.660, -1416.250, -89.084, 1370.850, -1130.850, 110.916},
    {"Rockshore West", 1997.220, 596.349, -89.084, 2377.390, 823.228, 110.916},
    {"Prickle Pine", 1534.560, 2583.230, -89.084, 1848.400, 2863.230, 110.916},
    {"Easter Basin", -1794.920, -50.096, -1.04, -1499.890, 249.904, 200.000},
    {"Leafy Hollow", -1166.970, -1856.030, 0.000, -815.624, -1602.070, 200.000},
    {"LVA Freight Depot", 1457.390, 863.229, -89.084, 1777.400, 1143.210, 110.916},
    {"Prickle Pine", 1117.400, 2507.230, -89.084, 1534.560, 2723.230, 110.916},
    {"Blueberry", 104.534, -220.137, 2.3, 349.607, 152.236, 200.000},
    {"El Castillo del Diablo", -464.515, 2217.680, 0.000, -208.570, 2580.360, 200.000},
    {"Downtown", -2078.670, 578.396, -7.6, -1499.890, 744.267, 200.000},
    {"Rockshore East", 2537.390, 676.549, -89.084, 2902.350, 943.235, 110.916},
    {"San Fierro Bay", -2616.400, 1501.210, -3.0, -1996.660, 1659.680, 200.000},
    {"Paradiso", -2741.070, 793.411, -6.1, -2533.040, 1268.410, 200.000},
    {"The Camel's Toe", 2087.390, 1203.230, -89.084, 2640.400, 1383.230, 110.916},
    {"Old Venturas Strip", 2162.390, 2012.180, -89.084, 2685.160, 2202.760, 110.916},
    {"Juniper Hill", -2533.040, 578.396, -7.6, -2274.170, 968.369, 200.000},
    {"Juniper Hollow", -2533.040, 968.369, -6.1, -2274.170, 1358.900, 200.000},
    {"Roca Escalante", 2237.400, 2202.760, -89.084, 2536.430, 2542.550, 110.916},
    {"Julius Thruway East", 2685.160, 1055.960, -89.084, 2749.900, 2626.550, 110.916},
    {"Verona Beach", 647.712, -2173.290, -89.084, 930.221, -1804.210, 110.916},
    {"Foster Valley", -2178.690, -599.884, -1.2, -1794.920, -324.114, 200.000},
    {"Arco del Oeste", -901.129, 2221.860, 0.000, -592.090, 2571.970, 200.000},
    {"Fallen Tree", -792.254, -698.555, -5.3, -452.404, -380.043, 200.000},
    {"The Farm", -1209.670, -1317.100, 114.981, -908.161, -787.391, 251.981},
    {"The Sherman Dam", -968.772, 1929.410, -3.0, -481.126, 2155.260, 200.000},
    {"Esplanade North", -1996.660, 1358.900, -4.5, -1524.240, 1592.510, 200.000},
    {"Financial", -1871.720, 744.170, -6.1, -1701.300, 1176.420, 300.000},
    {"Garcia", -2411.220, -222.589, -1.14, -2173.040, 265.243, 200.000},
    {"Montgomery", 1119.510, 119.526, -3.0, 1451.400, 493.323, 200.000},
    {"Creek", 2749.900, 1937.250, -89.084, 2921.620, 2669.790, 110.916},
    {"Los Santos International", 1249.620, -2394.330, -89.084, 1852.000, -2179.250, 110.916},
    {"Santa Maria Beach", 72.648, -2173.290, -89.084, 342.648, -1684.650, 110.916},
    {"Mulholland Intersection", 1463.900, -1150.870, -89.084, 1812.620, -768.027, 110.916},
    {"Angel Pine", -2324.940, -2584.290, -6.1, -1964.220, -2212.110, 200.000},
    {"Verdant Meadows", 37.032, 2337.180, -3.0, 435.988, 2677.900, 200.000},
    {"Octane Springs", 338.658, 1228.510, 0.000, 664.308, 1655.050, 200.000},
    {"Come-A-Lot", 2087.390, 943.235, -89.084, 2623.180, 1203.230, 110.916},
    {"Redsands West", 1236.630, 1883.110, -89.084, 1777.390, 2142.860, 110.916},
    {"Santa Maria Beach", 342.648, -2173.290, -89.084, 647.712, -1684.650, 110.916},
    {"Verdant Bluffs", 1249.620, -2179.250, -89.084, 1692.620, -1842.270, 110.916},
    {"Las Venturas Airport", 1236.630, 1203.280, -89.084, 1457.370, 1883.110, 110.916},
    {"Flint Range", -594.191, -1648.550, 0.000, -187.700, -1276.600, 200.000},
    {"Verdant Bluffs", 930.221, -2488.420, -89.084, 1249.620, -2006.780, 110.916},
    {"Palomino Creek", 2160.220, -149.004, 0.000, 2576.920, 228.322, 200.000},
    {"Ocean Docks", 2373.770, -2697.090, -89.084, 2809.220, -2330.460, 110.916},
    {"Easter Bay Airport", -1213.910, -50.096, -4.5, -947.980, 578.396, 200.000},
    {"Whitewood Estates", 883.308, 1726.220, -89.084, 1098.310, 2507.230, 110.916},
    {"Calton Heights", -2274.170, 744.170, -6.1, -1982.320, 1358.900, 200.000},
    {"Easter Basin", -1794.920, 249.904, -9.1, -1242.980, 578.396, 200.000},
    {"Los Santos Inlet", -321.744, -2224.430, -89.084, 44.615, -1724.430, 110.916},
    {"Doherty", -2173.040, -222.589, -1.0, -1794.920, 265.243, 200.000},
    {"Mount Chiliad", -2178.690, -2189.910, -47.917, -2030.120, -1771.660, 576.083},
    {"Fort Carson", -376.233, 826.326, -3.0, 123.717, 1220.440, 200.000},
    {"Foster Valley", -2178.690, -1115.580, 0.000, -1794.920, -599.884, 200.000},
    {"Ocean Flats", -2994.490, -222.589, -1.0, -2593.440, 277.411, 200.000},
    {"Fern Ridge", 508.189, -139.259, 0.000, 1306.660, 119.526, 200.000},
    {"Bayside", -2741.070, 2175.150, 0.000, -2353.170, 2722.790, 200.000},
    {"Las Venturas Airport", 1457.370, 1203.280, -89.084, 1777.390, 1883.110, 110.916},
    {"Blueberry Acres", -319.676, -220.137, 0.000, 104.534, 293.324, 200.000},
    {"Palisades", -2994.490, 458.411, -6.1, -2741.070, 1339.610, 200.000},
    {"North Rock", 2285.370, -768.027, 0.000, 2770.590, -269.740, 200.000},
    {"Hunter Quarry", 337.244, 710.840, -115.239, 860.554, 1031.710, 203.761},
    {"Los Santos International", 1382.730, -2730.880, -89.084, 2201.820, -2394.330, 110.916},
    {"Missionary Hill", -2994.490, -811.276, 0.000, -2178.690, -430.276, 200.000},
    {"San Fierro Bay", -2616.400, 1659.680, -3.0, -1996.660, 2175.150, 200.000},
    {"Restricted Area", -91.586, 1655.050, -50.000, 421.234, 2123.010, 250.000},
    {"Mount Chiliad", -2997.470, -1115.580, -47.917, -2178.690, -971.913, 576.083},
    {"Mount Chiliad", -2178.690, -1771.660, -47.917, -1936.120, -1250.970, 576.083},
    {"Easter Bay Airport", -1794.920, -730.118, -3.0, -1213.910, -50.096, 200.000},
    {"The Panopticon", -947.980, -304.320, -1.1, -319.676, 327.071, 200.000},
    {"Shady Creeks", -1820.640, -2643.680, -8.0, -1226.780, -1771.660, 200.000},
    {"Back o Beyond", -1166.970, -2641.190, 0.000, -321.744, -1856.030, 200.000},
    {"Mount Chiliad", -2994.490, -2189.910, -47.917, -2178.690, -1115.580, 576.083},
    {"Tierra Robada", -1213.910, 596.349, -242.990, -480.539, 1659.680, 900.000},
    {"Flint County", -1213.910, -2892.970, -242.990, 44.615, -768.027, 900.000},
    {"Whetstone", -2997.470, -2892.970, -242.990, -1213.910, -1115.580, 900.000},
    {"Bone County", -480.539, 596.349, -242.990, 869.461, 2993.870, 900.000},
    {"Tierra Robada", -2997.470, 1659.680, -242.990, -480.539, 2993.870, 900.000},
    {"San Fierro", -2997.470, -1115.580, -242.990, -1213.910, 1659.680, 900.000},
    {"Las Venturas", 869.461, 596.349, -242.990, 2997.060, 2993.870, 900.000},
    {"Red County", -1213.910, -768.027, -242.990, 2997.060, 596.349, 900.000},
    {"Los Santos", 44.615, -2892.970, -242.990, 2997.060, -768.027, 900.000}}
    for i, v in ipairs(streets) do
        if (x >= v[2]) and (y >= v[3]) and (z >= v[4]) and (x <= v[5]) and (y <= v[6]) and (z <= v[7]) then
            return v[1]
        end
    end
    return "Unknown"
end

function imgui.CenterTextColoredRGB(text)
    local width = imgui.GetWindowWidth()
    local style = imgui.GetStyle()
    local colors = style.Colors
    local ImVec4 = imgui.ImVec4

    local explode_argb = function(argb)
        local a = bit.band(bit.rshift(argb, 24), 0xFF)
        local r = bit.band(bit.rshift(argb, 16), 0xFF)
        local g = bit.band(bit.rshift(argb, 8), 0xFF)
        local b = bit.band(argb, 0xFF)
        return a, r, g, b
    end

    local getcolor = function(color)
        if color:sub(1, 6):upper() == 'SSSSSS' then
            local r, g, b = colors[1].x, colors[1].y, colors[1].z
            local a = tonumber(color:sub(7, 8), 16) or colors[1].w * 255
            return ImVec4(r, g, b, a / 255)
        end
        local color = type(color) == 'string' and tonumber(color, 16) or color
        if type(color) ~= 'number' then return end
        local r, g, b, a = explode_argb(color)
        return imgui.ImColor(r, g, b, a):GetVec4()
    end

    local render_text = function(text_)
        for w in text_:gmatch('[^\r\n]+') do
            local textsize = w:gsub('{.-}', '')
            local text_width = imgui.CalcTextSize(u8(textsize))
            imgui.SetCursorPosX( width / 2 - text_width .x / 2 )
            local text, colors_, m = {}, {}, 1
            w = w:gsub('{(......)}', '{%1FF}')
            while w:find('{........}') do
                local n, k = w:find('{........}')
                local color = getcolor(w:sub(n + 1, k - 1))
                if color then
                    text[#text], text[#text + 1] = w:sub(m, n - 1), w:sub(k + 1, #w)
                    colors_[#colors_ + 1] = color
                    m = n
                end
                w = w:sub(1, n - 1) .. w:sub(k + 1, #w)
            end
            if text[0] then
                for i = 0, #text do
                    imgui.TextColored(colors_[i] or colors[1], u8(text[i]))
                    imgui.SameLine(nil, 0)
                end
                imgui.NewLine()
            else
                imgui.Text(u8(w))
            end
        end
    end
    render_text(text)
end

function imgui.TextColoredRGB(text)
    local style = imgui.GetStyle()
    local colors = style.Colors
    local ImVec4 = imgui.ImVec4

    local explode_argb = function(argb)
        local a = bit.band(bit.rshift(argb, 24), 0xFF)
        local r = bit.band(bit.rshift(argb, 16), 0xFF)
        local g = bit.band(bit.rshift(argb, 8), 0xFF)
        local b = bit.band(argb, 0xFF)
        return a, r, g, b
    end

    local getcolor = function(color)
        if color:sub(1, 6):upper() == 'SSSSSS' then
            local r, g, b = colors[1].x, colors[1].y, colors[1].z
            local a = tonumber(color:sub(7, 8), 16) or colors[1].w * 255
            return ImVec4(r, g, b, a / 255)
        end
        local color = type(color) == 'string' and tonumber(color, 16) or color
        if type(color) ~= 'number' then return end
        local r, g, b, a = explode_argb(color)
        return imgui.ImColor(r, g, b, a):GetVec4()
    end

    local render_text = function(text_)
        for w in text_:gmatch('[^\r\n]+') do
            local text, colors_, m = {}, {}, 1
            w = w:gsub('{(......)}', '{%1FF}')
            while w:find('{........}') do
                local n, k = w:find('{........}')
                local color = getcolor(w:sub(n + 1, k - 1))
                if color then
                    text[#text], text[#text + 1] = w:sub(m, n - 1), w:sub(k + 1, #w)
                    colors_[#colors_ + 1] = color
                    m = n
                end
                w = w:sub(1, n - 1) .. w:sub(k + 1, #w)
            end
            if text[0] then
                for i = 0, #text do
                    imgui.TextColored(colors_[i] or colors[1], text[i])
                    imgui.SameLine(nil, 0)
                end
                imgui.NewLine()
            else imgui.Text(w) end
        end
    end

    render_text(text)
end

function apply_custom_style()
    imgui.SwitchContext()
    local style = imgui.GetStyle()
    style.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
end
apply_custom_style()
